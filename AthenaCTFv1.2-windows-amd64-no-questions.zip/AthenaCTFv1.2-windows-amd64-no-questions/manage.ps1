# ASCII-only for Windows PowerShell 5.1 compatibility.
# bjxctfptv2 platform launcher. The platform runs on Windows 10/11 x64 by
# itself; a container engine is only needed for container-based questions.
[CmdletBinding()]
param([ValidateSet('Check','Deploy','Start','Stop','StopDocker','InstallContainers','Publish')][string]$Action = 'Check')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$packageRoot = $PSScriptRoot
$configPath = Join-Path $packageRoot 'config.env'
$binaryPath = Join-Path $packageRoot 'bin\ctf-platform.exe'
$script:dockerExe = $null
$script:desktopExe = $null
$script:settings = @{}

function Say([string]$message) { Write-Host ((Get-Date -Format 'HH:mm:ss') + ' ' + $message) }
function Quote-Arg([string]$value) {
    $value = [regex]::Replace($value, '(\\*)"', '$1$1\"')
    $value = [regex]::Replace($value, '(\\+)$', '$1$1')
    return '"' + $value + '"'
}
function Native([string]$exe, [string[]]$arguments, [int]$seconds = 30) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $exe
    $info.Arguments = (($arguments | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $proc = New-Object Diagnostics.Process
    $proc.StartInfo = $info
    try {
        [void]$proc.Start()
        $outTask = $proc.StandardOutput.ReadToEndAsync()
        $errTask = $proc.StandardError.ReadToEndAsync()
        if (!$proc.WaitForExit($seconds * 1000)) {
            $proc.Kill()
            throw "Command timed out: $exe"
        }
        return @{Code=$proc.ExitCode; Out=$outTask.Result; Err=$errTask.Result}
    } finally { $proc.Dispose() }
}
function Find-Docker {
    $bases = @((Join-Path ([Environment]::GetFolderPath('ProgramFiles')) 'Docker\Docker'), (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Programs\DockerDesktop'))
    foreach ($base in $bases) {
        $app = Join-Path $base 'Docker Desktop.exe'
        $cli = Join-Path $base 'resources\bin\docker.exe'
        if (Test-Path -LiteralPath $app) { $script:desktopExe = $app }
        if (Test-Path -LiteralPath $cli) { $script:dockerExe = $cli }
    }
    if (!$script:dockerExe) {
        $cmd = Get-Command docker.exe -ErrorAction SilentlyContinue
        if ($cmd) { $script:dockerExe = $cmd.Source }
    }
}
function Docker([string[]]$arguments, [int]$seconds = 30) {
    if (!$script:dockerExe) { throw 'Docker CLI is missing. Container features are unavailable; run InstallContainers or connect an existing engine.' }
    $hostArg = $script:settings['CTF_DOCKER_HOST']
    if (!$hostArg) { throw 'No container engine endpoint is configured. Set CTF_DOCKER_HOST in config.env or run InstallContainers.' }
    Native $script:dockerExe (@('--host',$hostArg) + $arguments) $seconds
}
function Engine-Up {
    if (!$script:dockerExe) { return $false }
    try { $r = Docker @('info','--format','{{.OSType}}') 10; return ($r.Code -eq 0 -and $r.Out.Trim() -eq 'linux') } catch { return $false }
}
function Load-Config {
    if (!(Test-Path -LiteralPath $configPath)) { throw 'Missing config.env. Run deploy.cmd first.' }
    foreach ($line in Get-Content -LiteralPath $configPath -Encoding UTF8) {
        $line = $line.Trim().TrimStart([char]0xFEFF)
        if (!$line -or $line.StartsWith('#')) { continue }
        if ($line -notmatch '^([A-Z][A-Z0-9_]*)\s*=(.*)$') { throw 'Invalid config.env: expected KEY=VALUE.' }
        $key=$Matches[1]; $value=$Matches[2].Trim()
        if ($key -notmatch '^(CTF_[A-Z0-9_]+|GIN_MODE|TZ)$' -or $script:settings.ContainsKey($key)) { throw "Unsupported or duplicate setting: $key" }
        if ($value.Length -ge 2 -and (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'")))) { $value=$value.Substring(1,$value.Length-2) }
        $script:settings[$key]=$value
    }
    $defaults=@{CTF_APP_PORT='10010';CTF_USER_WEB_PORT='10011';CTF_ADMIN_WEB_PORT='10012';CTF_BIND_HOST='127.0.0.1';CTF_DB_PATH='data/ctf_platform.db';CTF_UPLOAD_ROOT='data/uploads';GIN_MODE='release';TZ='Asia/Shanghai';CTF_NETWORK_POLICY_READY='0';CTF_INSTANCE_HOST='auto';CTF_DOCKER_HOST=''}
    foreach($key in $defaults.Keys) { if (!$script:settings.ContainsKey($key)) { $script:settings[$key]=$defaults[$key] } }
    foreach($key in @('CTF_DB_PATH','CTF_UPLOAD_ROOT')) {
        if (![IO.Path]::IsPathRooted($script:settings[$key])) { $script:settings[$key]=[IO.Path]::GetFullPath((Join-Path $packageRoot $script:settings[$key])) }
    }
    # Container engine endpoint is configurable: local Docker Desktop named
    # pipe by default, or an existing engine (npipe://, unix://, tcp://,
    # http://) such as a remote Linux Docker host. Platform start never
    # requires it.
    if ($script:settings['CTF_DOCKER_HOST'] -and $script:settings['CTF_DOCKER_HOST'] -notmatch '^(npipe|unix|tcp|http)://') { throw 'CTF_DOCKER_HOST must start with npipe://, unix://, tcp:// or http://.' }
    if (!$script:settings['CTF_DOCKER_HOST'] -and $script:desktopExe) { $script:settings['CTF_DOCKER_HOST']='npipe:////./pipe/dockerDesktopLinuxEngine' }
    $script:ports=@([int]$script:settings['CTF_APP_PORT'],[int]$script:settings['CTF_USER_WEB_PORT'],[int]$script:settings['CTF_ADMIN_WEB_PORT'])
    if (@($script:ports | Sort-Object -Unique).Count -ne 3 -or @($script:ports | Where-Object { $_ -lt 1 -or $_ -gt 65535 }).Count) { throw 'Configure three distinct valid ports.' }
}
function script:HealthHostFrom([string]$bind) {
    switch ($bind) {
        '0.0.0.0' { return '127.0.0.1' }
        '::' { return '[::1]' }
        '::1' { return '[::1]' }
        default {
            if ($bind -eq '[::1]') { return '[::1]' }
            if ($bind -like '*:*') { return ('[' + $bind + ']') }
            return $bind
        }
    }
}
function Health([int]$port, [string]$path='/') {
    $hostName = HealthHostFrom $script:settings['CTF_BIND_HOST']
    try { return (Invoke-WebRequest -UseBasicParsing -Uri "http://$($hostName):$port$path" -TimeoutSec 3).StatusCode -eq 200 } catch { return $false }
}
function Platform-Processes {
    @(Get-Process -Name 'ctf-platform' -ErrorAction SilentlyContinue | Where-Object {
        try { [string]::Equals([IO.Path]::GetFullPath($_.Path),$binaryPath,[StringComparison]::OrdinalIgnoreCase) } catch { $false }
    })
}
# Pure support matrix, kept free of live system calls so it can be unit-tested
# with simulated inputs (see scripts/windows_support_tests.ps1).
# Returns: Supported (platform itself), Reason (when not), Notes (engine/OS).
function Get-PlatformSupport {
    param([string]$Caption,[int]$Build,[string]$OSArchitecture,[int]$ProcessorArchitecture,[bool]$Is64BitProcess,[bool]$HypervisorPresent,[bool]$FirmwareEnabled,[int]$ProductType)
    $notes = @()
    if ($ProcessorArchitecture -ne 9 -or !$Is64BitProcess) {
        return @{Supported=$false; Reason='This package requires 64-bit Windows (x64) and 64-bit PowerShell. 32-bit, ARM64 and other architectures are not supported by these binaries.'; Notes=$notes}
    }
    if ($Build -lt 17763) {
        return @{Supported=$false; Reason='Windows 10 version 1809 (build 17763) or newer x64 and newer x64 is the declared support scope of this package. Older builds (Windows 7/8, older LTSB/LTSC releases) are outside the tested scope.'; Notes=$notes}
    }
    if ($Caption -match 'Windows Server') {
        $notes += 'Windows Server detected: Docker Desktop is not supported on Server. The platform itself runs; use a remote Linux Docker engine (CTF_DOCKER_HOST) or the Linux package for container questions.'
    } else {
        if ($Build -lt 22000) { $notes += 'Windows 10 detected: supported. Docker Desktop on Windows 10 has its own version requirements; the newest Desktop release may refuse to install on this build.' }
        else { $notes += 'Windows 11 detected: supported.' }
    }
    if (!$HypervisorPresent -and !$FirmwareEnabled) {
        $notes += 'CPU virtualization appears disabled. The platform still runs; local Docker Desktop (container questions) would need virtualization/WSL 2 enabled first.'
    }
    return @{Supported=$true; Reason=''; Notes=$notes}
}
function Engine-State {
    if (!$script:dockerExe) { return 'not installed' }
    if (Engine-Up) { return 'ready' }
    return 'installed but not ready'
}
function Check-Host {
    $os=Get-CimInstance Win32_OperatingSystem
    $cpu=Get-CimInstance Win32_Processor | Select-Object -First 1
    $computer=Get-CimInstance Win32_ComputerSystem
    Find-Docker
    $support=Get-PlatformSupport -Caption $os.Caption -Build ([int]$os.BuildNumber) -OSArchitecture $os.OSArchitecture -ProcessorArchitecture $cpu.Architecture -Is64BitProcess ([Environment]::Is64BitProcess) -HypervisorPresent ([bool]$computer.HypervisorPresent) -FirmwareEnabled ([bool]$cpu.VirtualizationFirmwareEnabled) -ProductType $os.ProductType
    Say "OS: $($os.Caption) build $([int]$os.BuildNumber); RAM: $([Math]::Round($computer.TotalPhysicalMemory/1GB,1)) GiB; PowerShell: $($PSVersionTable.PSVersion)"
    if ($support.Supported) { Say 'Platform: this Windows host can run the platform.' }
    else { Say "Platform: NOT supported. $($support.Reason)" }
    foreach($note in $support.Notes) { Say "NOTE: $note" }
    Say "Container engine: $(Engine-State). Container questions need a ready Linux engine; platform management, empty-database initialization and static questions work without it."
    if ($os.ProductType -ne 1) { Say 'NOTE: Docker Desktop does not support Windows Server; configure CTF_DOCKER_HOST to an existing Linux engine or use the Linux package.' }
    Say "Platform binary present: $(Test-Path -LiteralPath $binaryPath); config.env present: $(Test-Path -LiteralPath $configPath)"
    if(Is-Admin) { foreach($f in @('Microsoft-Windows-Subsystem-Linux','VirtualMachinePlatform')) { $feature=Get-WindowsOptionalFeature -Online -FeatureName $f; Say "$f : $($feature.State)" } }
    Say 'Check distinguishes: platform runnable / container engine not ready / truly unsupported. Nothing was installed or changed.'
}
function Start-Platform {
    if (!(Test-Path -LiteralPath $binaryPath)) { throw 'Missing platform executable. Extract the complete Windows package.' }
    foreach($side in @('user','admin')) { if (!(Test-Path -LiteralPath (Join-Path $packageRoot "web\$side\index.html"))) { throw "Missing $side frontend." } }
    # The platform starts WITHOUT any container engine. Docker Desktop is not
    # auto-started here; container questions simply stay unavailable until an
    # engine is ready (check.cmd reports the current state).
    $existing=@(Platform-Processes)
    if ($existing.Count) {
        if ((Health $script:ports[0] '/api/health') -and (Health $script:ports[1]) -and (Health $script:ports[2])) { Say 'Platform is already running.'; return }
        throw 'This platform process is running but unhealthy. Inspect logs and run stop.cmd before retrying.'
    }
    $listeners=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $script:ports -contains $_.LocalPort })
    if($listeners.Count) { throw 'A configured port is in use by another process. No process was terminated.' }
    # Scrub inherited CTF_*/DOCKER_* variables first: a parent shell's bank
    # root, vault root or Docker endpoint must never leak into this
    # package's platform process. Then apply exactly this package's
    # config + defaults (explicit, validated config always wins).
    $envKeys=@([Environment]::GetEnvironmentVariables('Process').Keys | Where-Object { $_ -match '^(CTF_|DOCKER_)' })
    foreach($key in $envKeys) { [Environment]::SetEnvironmentVariable($key,$null,'Process') }
    foreach($key in $script:settings.Keys) { [Environment]::SetEnvironmentVariable($key,$script:settings[$key],'Process') }
    if ($script:dockerExe) { $dockerBin=Split-Path -Parent $script:dockerExe; $env:PATH=$dockerBin+';'+$env:PATH }
    foreach($dir in @('logs','run')) { New-Item -ItemType Directory -Path (Join-Path $packageRoot $dir) -Force | Out-Null }
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $out=Join-Path $packageRoot "logs\platform-$stamp.out.log"; $err=Join-Path $packageRoot "logs\platform-$stamp.err.log"
    $arguments=@('-web-root',(Join-Path $packageRoot 'web'),'-user-port',"$($script:ports[1])",'-admin-port',"$($script:ports[2])")
    $p=Start-Process -FilePath $binaryPath -ArgumentList (($arguments | ForEach-Object { Quote-Arg $_ }) -join ' ') -WorkingDirectory $packageRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    @{pid=$p.Id;binary=$binaryPath;started_utc=$p.StartTime.ToUniversalTime().ToString('o');ports=$script:ports} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $packageRoot 'run\platform.json') -Encoding UTF8
    $ready=$false; $deadline=(Get-Date).AddSeconds(60)
    while((Get-Date) -lt $deadline -and !$p.HasExited) {
        if ((Health $script:ports[0] '/api/health') -and (Health $script:ports[1]) -and (Health $script:ports[2])) { $ready=$true; break }
        Start-Sleep -Seconds 1
    }
    if (!$ready) { if (!$p.HasExited) { Stop-Process -Id $p.Id -Force }; throw "Startup failed. Inspect $err" }
    $accessHost = HealthHostFrom $script:settings['CTF_BIND_HOST']
    Say "Administrator: http://$($accessHost):$($script:ports[2]) ; contestant: http://$($accessHost):$($script:ports[1])"
    Say "Container engine: $(Engine-State). Without a ready engine, container questions are unavailable; everything else works."
    Say "Listening on $($script:settings['CTF_BIND_HOST']). Logs: $packageRoot\logs"
}
function Is-Admin {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
# Explicit, opt-in installation of local container support (WSL 2 + Docker
# Desktop). Never run by deploy/start; never removes an existing engine. A
# newest Desktop release may refuse older Windows 10 builds; that is reported
# instead of promising support.
function Install-Containers {
    if (!(Is-Admin)) {
        $arguments=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-Action','InstallContainers')
        $elevated=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList (($arguments | ForEach-Object { Quote-Arg $_ }) -join ' ') -Verb RunAs -Wait -PassThru
        exit $elevated.ExitCode
    }
    Find-Docker
    if ($script:dockerExe) { Say "Existing Docker CLI found at $($script:dockerExe). Keeping it; nothing will be replaced or uninstalled."; }
    # Capability pre-check BEFORE any feature/WSL/download change: the newest
    # Docker Desktop supports Windows 11 22631+ and Windows 10 22H2 19045
    # while under Microsoft support; other builds/releases have no verified
    # Desktop support, so point at manual install / engine reuse instead of
    # running an installer that would certainly fail.
    $osInfo=Get-CimInstance Win32_OperatingSystem
    $buildNumber=[int]$osInfo.BuildNumber
    $verifiedDesktop = ($buildNumber -eq 19045) -or ($buildNumber -ge 22631)
    if (!$verifiedDesktop) {
        Say "Docker Desktop support for this Windows build ($buildNumber) cannot be verified; skipping the automatic installer."
        Say 'Options: (1) reuse an existing engine - set CTF_DOCKER_HOST in config.env;'
        Say '          (2) manually install a Desktop release that supports this Windows version per https://docs.docker.com/desktop/setup/install/windows-install/'
        Say 'The platform works without container support; container questions stay unavailable until an engine is ready.'
        exit 2
    }
    $restart=$false
    foreach($featureName in @('Microsoft-Windows-Subsystem-Linux','VirtualMachinePlatform')) {
        $feature=Get-WindowsOptionalFeature -Online -FeatureName $featureName
        if($feature.State -ne 'Enabled') {
            $result=Enable-WindowsOptionalFeature -Online -FeatureName $featureName -All -NoRestart
            $restart=$true
        }
    }
    if($restart) { Say 'Windows features installed. Restart Windows, then run install-containers.cmd again. No automatic restart was performed.'; exit 3010 }
    $wsl=Join-Path ([Environment]::GetFolderPath('Windows')) 'System32\wsl.exe'
    $version=Native $wsl @('--version') 20
    $versionText=($version.Out+$version.Err).Replace([string][char]0,'')
    $versionMatch=[regex]::Match($versionText,'\d+\.\d+\.\d+')
    if($version.Code -ne 0 -or !$versionMatch.Success -or [version]$versionMatch.Value -lt [version]'2.1.5') {
        Say 'Installing/updating WSL from Microsoft...'
        $result=Native $wsl @('--update','--web-download') 600
        if($result.Code -ne 0) { throw 'WSL update failed. Check internet access, restart if requested, and rerun install-containers.cmd.' }
    }
    if(!$script:desktopExe -or !$script:dockerExe) {
        $downloadDir=Join-Path $packageRoot 'install-cache'
        New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
        $installer=Join-Path $downloadDir 'DockerDesktopInstaller.exe'
        Say 'Downloading Docker Desktop from docker.com...'
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri 'https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe' -OutFile $installer
        $signature=Get-AuthenticodeSignature -LiteralPath $installer
        if($signature.Status -ne 'Valid' -or !$signature.SignerCertificate -or $signature.SignerCertificate.Subject -notmatch '(?i)Docker') { throw 'Docker installer signature verification failed. Installer was not executed.' }
        Say 'Complete the Docker installer and its license prompts. Re-run install-containers.cmd after any required restart.'
        $install=Start-Process -FilePath $installer -ArgumentList 'install --backend=wsl-2' -Wait -PassThru
        if($install.ExitCode -eq 3010) { Say 'Docker installation requires a Windows restart. Re-run install-containers.cmd afterwards.'; exit 3010 }
        if($install.ExitCode -ne 0) { throw "Docker installer exited with $($install.ExitCode)." }
        Find-Docker
        if(!$script:desktopExe -or !$script:dockerExe) { throw 'Docker installation not yet available. Restart Windows and rerun install-containers.cmd.' }
    }
    Say 'Container support installed. Start Docker Desktop, then run check.cmd to confirm the engine is ready.'
}
function Stop-Platform {
    foreach($p in @(Platform-Processes)) {
        Say "Stopping this package's platform process $($p.Id)."
        Stop-Process -Id $p.Id -Force
        if (!$p.WaitForExit(10000)) { throw 'Platform process did not stop.' }
    }
    $owned = @(Platform-Processes)
    if ($owned.Count) { throw 'Platform is still running.' }
    $pidPath=Join-Path $packageRoot 'run\platform.json'
    if(Test-Path -LiteralPath $pidPath) { Remove-Item -LiteralPath $pidPath }
    Say 'API, contestant UI and administrator UI for this package are stopped.'
}
function Stop-Docker-Everything {
    # Explicit maintenance action only: shuts the whole local Docker Desktop
    # engine down, including containers from OTHER applications on this host.
    Stop-Platform
    if(Engine-Up) {
        $running=Docker @('ps','-q')
        if($running.Code -ne 0) { throw 'Could not enumerate running Docker containers.' }
        $ids=@($running.Out -split '\s+' | Where-Object {$_})
        if($ids.Count) { Say 'Stopping all containers on this local Docker Engine (explicit maintenance option)...'; $stopped=Docker (@('stop','--time','20')+$ids) 180; if($stopped.Code -ne 0) { throw 'Some containers could not stop. Docker was left running for diagnosis.' } }
    }
    $apps=@(Get-Process -Name 'Docker Desktop','com.docker.backend' -ErrorAction SilentlyContinue)
    if((Engine-Up) -or $apps.Count) {
        if(!$script:dockerExe) { throw 'Docker is running, but the CLI is missing.' }
        Say 'Stopping Docker Desktop and its Linux Engine...'
        $result=Native $script:dockerExe @('desktop','stop','--timeout','60') 75
        if($result.Code -ne 0) { Say $result.Err }
    }
    $deadline=(Get-Date).AddSeconds(30)
    do { $apps=@(Get-Process -Name 'Docker Desktop','com.docker.backend','com.docker.proxy','vpnkit' -ErrorAction SilentlyContinue); if(!$apps.Count){break}; Start-Sleep -Seconds 2 } while((Get-Date) -lt $deadline)
    if((Engine-Up) -or $apps.Count -or (Test-Path '\\.\pipe\dockerDesktopLinuxEngine')) { throw 'Docker is not fully stopped. Inspect Docker Desktop.' }
    Say 'Docker Desktop and its Linux Engine are stopped. Data and images are retained.'
}

try {
    if($Action -in @('Deploy','InstallContainers') -and !(Is-Admin)) {
        $arguments=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-Action',$Action)
        $elevated=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList (($arguments | ForEach-Object { Quote-Arg $_ }) -join ' ') -Verb RunAs -Wait -PassThru
        exit $elevated.ExitCode
    }
    if($Action -eq 'Check') { Check-Host; exit 0 }
    if($Action -eq 'InstallContainers') { Install-Containers; exit 0 }
    if($Action -eq 'StopDocker') { Load-Config; Find-Docker; Stop-Docker-Everything; exit 0 }
    if($Action -eq 'Deploy') {
        Check-Host
        if(!(Test-Path -LiteralPath $binaryPath)) { throw 'Extract the complete Windows runtime package before deploying.' }
        if(!(Test-Path -LiteralPath $configPath)) { Copy-Item -LiteralPath (Join-Path $packageRoot 'config.env.example') -Destination $configPath }
        Say 'Deployed for local use. Container questions need a ready engine: run install-containers.cmd (opt-in) or set CTF_DOCKER_HOST in config.env to an existing engine.'
    }
    Load-Config
    Find-Docker
    if($Action -in @('Deploy','Start')) {
        Start-Platform
        if($script:settings['CTF_BIND_HOST'] -eq '127.0.0.1') { Say 'Initialize your administrator locally and save the generated random password, then run publish.cmd to enable all network interfaces.' }
    } elseif($Action -eq 'Publish') {
    $statusHost = HealthHostFrom $script:settings['CTF_BIND_HOST']
        $status=Invoke-RestMethod -Uri ("http://" + $statusHost + ":" + $($script:ports[0]) + "/api/admin/bootstrap-status") -TimeoutSec 5
        if($status.data.need_bootstrap -ne $false) { throw 'Initialize the administrator on this host first, then run publish.cmd.' }
        Stop-Platform
        $text=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
        if($text -match '(?m)^CTF_BIND_HOST=') { $text=[regex]::Replace($text,'(?m)^CTF_BIND_HOST=.*$','CTF_BIND_HOST=0.0.0.0') } else { $text += "`r`nCTF_BIND_HOST=0.0.0.0`r`n" }
        [IO.File]::WriteAllText($configPath,$text,(New-Object Text.UTF8Encoding($true)))
        $script:settings=@{}; Load-Config; Find-Docker; Start-Platform
        Say "Allow TCP $($script:ports -join ', ') only from trusted competition/admin networks in Windows Firewall. No global firewall rules were changed."
    } elseif($Action -eq 'Stop') {
        # Default stop touches ONLY this package's platform process, verified
        # by full executable path. No Docker API is called at all: name
        # prefixes cannot prove which installation a container belongs to.
        # Use stop-docker.cmd for the explicit whole-engine maintenance
        # shutdown (affects other applications' containers too).
        Stop-Platform
        Say 'Platform stopped. Containers and the Docker engine itself were not touched; use stop-docker.cmd for the explicit whole-engine maintenance shutdown.'
    }
} catch { Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red; exit 1 }
