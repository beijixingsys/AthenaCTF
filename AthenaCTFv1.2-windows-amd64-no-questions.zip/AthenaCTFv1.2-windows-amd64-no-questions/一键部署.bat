@echo off
call "%~dp0deploy.cmd"
