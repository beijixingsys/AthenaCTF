@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage.ps1" -Action Deploy
set "CTF_EXIT=%ERRORLEVEL%"
pause
exit /b %CTF_EXIT%
