@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage.ps1" -Action Check
set "CTF_EXIT=%ERRORLEVEL%"
pause
exit /b %CTF_EXIT%
