@echo off
setlocal
echo EXPLICIT maintenance shutdown: stops the whole Docker Desktop engine and
echo ALL its containers, including ones from other applications. The platform
echo is stopped first. Use stop.cmd for a platform-only stop.
pause
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage.ps1" -Action StopDocker
set "CTF_EXIT=%ERRORLEVEL%"
pause
exit /b %CTF_EXIT%
