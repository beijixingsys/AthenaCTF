@echo off
call "%~dp0stop.cmd"
