@echo off
setlocal
echo Optional: installs WSL 2 and Docker Desktop for container-based questions.
echo The platform itself works without this step; an existing engine is kept.
pause
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage.ps1" -Action InstallContainers
set "CTF_EXIT=%ERRORLEVEL%"
if "%CTF_EXIT%"=="3010" echo Restart Windows, then run install-containers.cmd again.
pause
exit /b %CTF_EXIT%
