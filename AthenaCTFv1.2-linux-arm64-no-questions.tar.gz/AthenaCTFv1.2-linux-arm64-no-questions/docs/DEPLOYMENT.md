# 部署与容量建议

适用范围：约 100 名选手、约 30 支队伍、每队同时 1 个 Web 靶机；同一队伍成员共享实例和成绩。默认总实例配额 40、每队 1、有效期 60 分钟。平台使用单进程 Go/Gin + SQLite WAL，不需要 Redis/MySQL。数据库放本地 SSD，不能放 NFS，也不要启动多个 API 副本共享库。

## 服务器

推荐将平台控制节点和题目节点分开，避免有意脆弱的题目访问平台数据。

| 节点 | 建议配置 | 用途 |
|---|---|---|
| 平台节点 | 4 vCPU / 8 GB RAM / 100 GB SSD | Go API、两个静态前端、Nginx、SQLite、附件 |
| 题目节点 | 16 vCPU / 32 GB RAM / 200 GB SSD | 约 30 个同时运行的 Web 容器、预拉镜像 |
| 合并部署的资源起点 | 16 vCPU / 32 GB RAM / 200–300 GB SSD | 内部演练可用；题目与平台的隔离弱于独立 VM |

容量估算不是硬件性能保证：30 × 256 MiB = 7.5 GiB 靶机内存；30 × 512 MiB = 15 GiB。再为系统、Docker、镜像层缓存和余量预留约 8–12 GiB。每题 0.5 CPU 的 30 个满载容器需要约 15 个 CPU 核的配额总量。大型 Java/PHP 题或数据库题按单题实测增加内存；题目模板默认 256 MiB，可设到 2 GiB。普通内部 LAN 建议千兆，远程比赛按附件大小与下载并发测带宽，20–50 Mbps 为轻附件起点。

准备 Ubuntu Server 24.04 LTS 或受支持的同等 Linux、Docker Engine、Nginx、SSH、正确的 NTP 时间。构建机安装受支持的 Go（示例镜像 1.27.1）和 Node.js 24 LTS；运行主机只需编译出的 Go 程序、Docker CLI、Nginx、Python 3.11+（备份工具）。Windows Docker Desktop 仅作为开发/验收环境。

## 发布

1. 在 Linux 构建机执行 `bash deploy/build.sh /absolute/path/to/release`。前端固定使用同源 `/api`，不要把开发地址写入生产 bundle。
2. 新建非 root 的 `ctf` 服务账户，其 passwd home 设为 `/etc/bjxctf/ssh-home`（SSH 不应只依赖 HOME 环境变量）；把 release 的 `bin`、`web`、`scripts`、`deploy` 复制到 `/opt/bjxctf/`，把现有 SQLite 数据库与 uploads 放在 `/var/lib/bjxctf/`，所有者为 `ctf`。升级前使用备份脚本，首次空库则在管理端创建超级管理员；没有默认密码。
3. 将 `deploy/platform.env.example` 放到 `/etc/bjxctf/platform.env` 并修改域名、节点地址。设置 `TZ=Asia/Shanghai`，迁移原有无时区赛程时保持同一时区。
4. 题目节点创建仅供平台使用的 `ctf-runner` SSH 账户，安装 Docker 并赋予该账户使用 Docker 的权限。它等价于该题目节点的高权限账户，所以仅允许平台节点通过管理网络访问 SSH。平台服务账户的专用私钥和已核验的 known_hosts 放在 `/etc/bjxctf/ssh-home/.ssh/`，权限 0700/0600，禁止关闭主机密钥校验。先以 `ctf` 用户验证 `docker --host ssh://ctf-runner@NODE info`。
5. 合并 `deploy/docker-daemon.json.example` 到题目节点的 daemon 配置。独立实例各用一个 bridge 网络，30 个实例加遗留网络可能耗尽默认地址池；示例为每实例分配 /25，一个 /16 地址池最多提供 512 个实例网络（仍需扣除占用和预留），覆盖 30 队 × 9 题的 270 个靶机。**先核对该地址段与公司网络/VPN不冲突**，再计划性重启 Docker，不要直接覆盖其他 daemon 配置。
6. 预拉取所有题目镜像。平台使用 `--pull=never`，避免选手启动时访问镜像仓库或下载阻塞。先在题目节点运行 `docker build -t bjxctf/web-dynamic:acceptance examples/web-dynamic` 可构建随附验收题。
7. 在题目节点安装 `deploy/firewall.sh` 与 `deploy/ctf-firewall.service`，确保CIDR与地址池一致、Docker使用iptables后端，启用防火墙服务。该策略只管理CTF专属链，阻止靶机新建出站连接及访问宿主管理面，保留已建立连接的回包。用 `CTF_VERIFY_NETWORK_ACL=1` 的网络验收确认跨队访问阻断，再把平台环境中的 `CTF_NETWORK_POLICY_READY=1`。默认生产模式拒绝启动未确认网络策略的靶机。随后安装 `deploy/ctf-platform.service`，执行 `systemctl daemon-reload && systemctl enable --now ctf-platform`。API 只监听 127.0.0.1:10010，通过 `journalctl -u ctf-platform` 排查。
8. 按 `deploy/nginx.conf.example` 配置两个域名、TLS 证书，执行 `nginx -t` 后加载。选手域名禁止 `/api/admin/`；管理域名只允许管理员 LAN/VPN 访问。不要通过 Vite 开发服务器对外部署。
9. 在管理端配置赛事开始/结束时间、队伍和选手，给队伍分配赛事，题库绑定题目及分值。Web 题选择 dynamic Flag、填入预拉镜像与容器内部端口（如 `8080/tcp`）；不得配置宿主挂载或 Docker 特权。无有效赛程不能看题、启动或提交。

运行器检测 Docker Engine 版本：29 及以上使用 `--subnet 0.0.0.0/25`，让 Docker 从已配置地址池中自动分配较小子网，避免默认大网段在约 30 个独立网络时耗尽；旧版引擎仍使用 daemon 的地址池粒度。此功能不修改 Docker 配置、不重启其他容器，也不替代第 5–7 步的专用地址池和 ACL。Docker 29 创建的这类网络不能直接沿用到旧版引擎；降级应在停赛、全部实例回收后进行。[Docker 自动子网分配说明](https://docs.docker.com/engine/network/#automatic-subnet-allocation)。

平台节点首次安装的目录和权限示例（以 root 执行，先将 release 文件放入 `/opt/bjxctf`）：

```bash
useradd --system --home-dir /etc/bjxctf/ssh-home --shell /usr/sbin/nologin ctf
install -d -o ctf -g ctf -m 0750 /var/lib/bjxctf /var/lib/bjxctf/uploads /srv/ctf-backups
install -d -o ctf -g ctf -m 0700 /etc/bjxctf/ssh-home /etc/bjxctf/ssh-home/.ssh
install -m 0640 -o root -g ctf /opt/bjxctf/deploy/platform.env.example /etc/bjxctf/platform.env
# 编辑环境文件，安装并核验专用 SSH 密钥和 known_hosts；导入原数据时恢复 ctf 属主。
install -m 0644 /opt/bjxctf/deploy/ctf-platform.service /etc/systemd/system/ctf-platform.service
chmod 0755 /opt/bjxctf/bin/ctf-platform
systemctl daemon-reload
systemctl enable --now ctf-platform
```

题目节点安装 `firewall.sh` 到 `/opt/bjxctf/deploy/`，将 `ctf-firewall.service` 复制到 `/etc/systemd/system/`，核对 CIDR 后执行 `systemctl daemon-reload && systemctl enable --now ctf-firewall`。网络测试从具备 Go SDK 的构建机运行包内 `golang/` 源码，通过 Docker SSH 连接专用验收/题目节点，参见 TESTING；正式运行主机无需 Go。

## 网络边界

`firewall.sh` 负责题目出站和题目到宿主访问，并不替代入站边界。请在上游防火墙/交换机 ACL 仅允许比赛网段访问题目节点映射端口，SSH 仅允许平台管理 IP，拒绝其他来源；管理 Nginx 示例默认仅允许私网和回环，上线时收紧为实际管理员 VPN/LAN 网段。若完全使用宿主规则，映射端口需在 DOCKER-USER 的 DNAT 后转发链限制来源，SSH 在 INPUT 链限制，不能只配置 UFW。修改后从允许与拒绝的两个网络分别验证。

选手需要访问平台 HTTPS 及题目节点映射端口。实例端口由 Docker 动态分配；以实例 API 返回为准。题目节点仅向比赛 LAN/VPN 开放这些端口，SSH 仅向控制节点开放，不向选手开放 Docker API 2375/2376。部署前检查当前引擎分配端口范围并配置防火墙，不能假定某一固定区间。

实例采用独立 bridge、ICC=false、固定本地DNS；设置 CPU、内存、禁 swap 扩容、PID 上限、cap-drop、no-new-privileges 和有限日志。真实 Docker 29 测试发现 `--internal` 网络不能正常发布宿主端口，因此使用普通 bridge；同时发现独立 bridge **不能单独保证已发布端口的跨队隔离**。必须配合上述宿主ACL，镜像不得依赖互联网才能启动。容器仍共用内核，生产建议题目节点使用独立 VM；对内核利用题应另设强隔离环境，本运行器只面向普通 Web/应用题。

仅本地功能验收可设置 `GIN_MODE=debug` 与 `CTF_ALLOW_UNFILTERED_DOCKER=1`，此时不宣称网络隔离已验收。`GIN_MODE=release` 不接受该例外。`CTF_NETWORK_POLICY_READY` 是部署人员的验收声明，平台不能自行证明外部主机防火墙规则正确；防火墙持久化及重启复验必须纳入运维流程。

Docker 发布端口的防火墙规则与 UFW 有特殊交互。必须检查 Docker 的转发规则/DOCKER-USER 或对应 nftables 规则，而不能仅凭 `ufw status` 判定安全。同时在宿主 INPUT/上游 ACL 拒绝题目 bridge 源地址访问管理 SSH、平台节点及公司内网。保留 ESTABLISHED/RELATED 返回流量。具体规则应按实际网卡、比赛网段和 Docker 防火墙后端验收，避免复制错误网段导致停赛。

## 动态 Flag 和镜像约定

平台每次新建实例用加密随机源生成 `flag{随机64位十六进制}`，通过子进程环境中的 `FLAG` 传给 Docker `--env FLAG`；数据库只保存摘要，选手 API 不返回 Flag。题目入口可将其写入 `/flag` 或题目程序内存。停止/过期后 Flag 无效，重启重新生成；同一正在运行的实例重复点启动是幂等操作，不重新生成。续期不改变 Flag，且不能超过赛事结束时间。

示例 `examples/web-dynamic` 是特意简单的验收题，通过 `/robots.txt` 找到 `/training/flag`。它用于证明端口、Flag 注入和判题链路，应替换为正式比赛题。平台不支持任意 shell 启动命令、宿主目录挂载、host 网络或 privileged 参数。Docker 管理员仍可查看容器环境，只有可信运维人员应能访问 Docker。

## 备份、恢复与升级

以 `ctf` 身份执行：

```bash
python3 /opt/bjxctf/scripts/backup.py --database /var/lib/bjxctf/ctf_platform.db --uploads /var/lib/bjxctf/uploads --destination /srv/ctf-backups
```

该工具用 SQLite backup API 获取一致快照，并备份上传目录、生成 SHA256 清单。比赛期间建议每 5–15 分钟备份并异地保存；保留期按组织要求设置。此仓库不替你自动配置系统定时任务。不要仅复制 WAL 正在使用的主 db 文件。

恢复先停 API，验证清单与数据库 `PRAGMA integrity_check`，还原数据库和 uploads、确认属主，再启动。恢复点之后启动的容器可能成为孤儿：维护时按平台实例 ID/标签核查，先停止对应容器再删网络，不要批量清理其他 Docker 服务。开赛前演练一次恢复。升级保留备份，源码迁移会保留旧记录；若要回滚代码，应同时还原配套数据库快照。

数据库迁移可单独运行：`CTF_DB_PATH=/path/to/copied.db ./bin/ctf-platform -migrate-only`，只迁移表结构和权限，不启动 API 或 Docker worker。升级前先对备份副本执行并检查完整性。已识别的旧 `admin-type-super` 单角色、零权限关系布局会一次性转换为显式权限并留下审计，后续主动清空权限不会自动恢复。

备份时应暂停管理员上传、编辑和删除附件，或使用协调的文件系统快照，避免数据库与文件分别拍摄时发生变动。仅无 `.incomplete` 后缀的目录表示完整备份。不要从不可信来源恢复附件压缩包。

## 验收与容量测试

见 `docs/TESTING.md` 和本次生成的测试报告。上线前必须在最终服务器、真实 30 个题目镜像下做启动风暴、CPU/内存满载、访问、Flag、到期回收及网络隔离验收。本机 100 用户 HTTP 测试只能覆盖平台读写负载，不能替代真实题目的资源测试或第三方渗透测试。

资料来源：[Docker 资源限制](https://docs.docker.com/engine/containers/resource_constraints/)、[Docker 防火墙行为](https://docs.docker.com/engine/network/packet-filtering-firewalls/)、[Docker 安全模型](https://docs.docker.com/engine/security/)、[SQLite WAL](https://www.sqlite.org/wal.html)、[Go 发布版本](https://go.dev/dl/)。服务器规格是基于上述配额与并发的容量估算，不是来源文档给出的保证值。
