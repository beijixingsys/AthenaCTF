# 当前开发机 .runtime 数据与日志说明

结论：**当前主机的 `.runtime` 不是纯日志目录，不能整体删除。** 本文于 2026-09-30 依据实际运行进程和 `config.env` 更新；以后切换版本应重新确认引用路径。

## 当前启动脚本实际依赖

| 当前路径（相对项目根） | 内容和影响 |
|---|---|
| `.runtime/current-backend.json` | 记录当前可执行程序、前端、配置启动脚本等路径。缺失或损坏时，启动器可从备用记录或唯一且可核对的运行进程恢复；不应主动删除。 |
| `.runtime/launcher/last-backend.json` | 启动记录的备用副本，不是日志。主记录丢失且平台已停止时，用它恢复下一次启动。 |
| `.runtime/awdplus-release-20260930/bin/ctf-platform.exe` | 当前运行程序。删除后无法再次启动。 |
| `.runtime/awdplus-release-20260930/web/` | 两个前端的生产资源。删除后页面不可用或启动检查失败。 |
| `.runtime/awdplus-release-20260930/config.env` | 指定监听、数据库、上传、Docker、题库等配置。不能当作日志删除；可能含部署信息，应限制读取权限。 |
| `.runtime/awdplus-release-20260930/start.ps1` 等 | 当前版本启动入口/运行目录依据，保留。 |
| `.runtime/docker-cli-config/` | 根目录启动/关闭脚本使用的 Docker CLI 配置目录，可重建但不应混同日志。其他 docker-config 目录可能含连接设置/认证信息。 |

状态文件内 PID 可能属于历史启动，不能仅凭 PID 判断当前进程或据此删除文件；当前脚本还会核对进程路径/监听端口。

关闭脚本不再强制要求主记录存在：它根据本项目 `.runtime` 下 `bin/ctf-platform.exe` 的实际可执行路径确认进程，停止前再次核对路径和创建时间。不会仅凭端口或历史 PID 结束其他程序。即使平台已经停止，也会继续关闭本机 Docker Desktop、Engine 及其专用 WSL 发行版；不执行全局 `wsl --shutdown`。可重复点击，已停止时也正常完成。检查而不关停可执行 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/stop_competition_platform.ps1 -CheckOnly`。

## 比赛业务数据实际在哪里

当前配置明确指向：

- `golang/data/ctf_platform.db`：管理员、选手、队伍、赛事、题目、容器模板、成绩、提交、系统设置等。
- `golang/data/uploads/`：当前已上传的题目附件、封面及其他文件。
- `Agentctf/timu/`：现有题库原文件，供题库导入等功能读取。
- Docker 自己的数据存储：镜像、容器和卷，不存放在本项目 `.runtime` 里。Windows Docker Desktop 的虚拟磁盘位置取决于其设置，不应直接删除。

数据库同目录出现的 `ctf_platform.db-wal`、`ctf_platform.db-shm` **不是日志文件**，不要手动清理；WAL 可能包含尚未并入主数据库的事务。请通过 SQLite 一致备份或停止平台后按完整数据库目录备份。

本次“无赛题”源码/部署包故意不复制数据库和 uploads，否则会把目前的赛题与答案、账号和历史成绩带到新主机。它是一份源码备份和空平台交付包，不能用来恢复现有比赛业务数据。

## .runtime 里其他重要内容

- `before-*`、`pre-*`、`private-backup/`、`*.db`、`*.db-wal`、`*.db-shm`：旧版本或操作前的数据备份，可能用于回滚。它们不是日志，先确认备份保留策略再处理。
- `distribution-*`、`clean-distribution-*`、`release-*`、`*-platform-*`、`*-build-*`：历史发行构建、前端资源、可执行程序和测试环境。若被当前指针/脚本引用必须保留；未被引用的旧构建在另有备份后可清理。
- `agent-image-contexts/`、`agent-runtime-maintenance/`：题目镜像构建与维护材料，可能用于重建。删除会丢失本地构建材料，但不等于删除 Docker 已存在镜像。
- `gocache-*`、`gotmp-*`、`clean-build-cache/`、`clean-build-tmp/`：编译缓存/临时文件。确认没有编译进程使用后可删除，之后构建会重新生成。
- `*-acceptance-*`、`e2e-*`、验收 JSON、PNG：隔离测试数据库、截图和报告，有排错/追溯用途。它们不都是日志，也可能包含测试数据。

## 不需要的日志能否删除

可以。停止平台和相关构建/测试任务后，删除**已确认是日志**的文件不会删除账号、赛题或成绩，例如：

- `.runtime/launcher/logs/` 下的启动/停止日志；
- `.runtime/awdplus-release-20260930/logs/` 中的 `.out.log`、`.err.log`；
- 其他已确认属于历史启动或构建输出的 `.log` 文件。

本次没有执行日志清理。建议正式比赛结束后保留必要的审计/故障日志，再定期按日期清理。不要用“删除整个 `.runtime`”代替清日志，也不要把所有 `.json`、`.db*`、`.env` 文件视作日志。删除正在写入的日志可能失败，或影响故障诊断，因此先停对应服务。

新部署包已分离 `data/`、`logs/`、`run/` 和 `config.env`，不依赖原机 `.runtime`。迁移时只解压新包进行空平台初始化，无需拷贝原 `.runtime`。
