"""Back up a live SQLite database and its uploaded files using the standard library.

python3 backup.py --database /var/lib/bjxctf/ctf_platform.db \
  --uploads /var/lib/bjxctf/uploads --destination /srv/ctf-backups

Only directories without an ``.incomplete`` suffix are completed backups. Uploads
should not be modified or deleted during a backup; SQLite itself may remain live.
"""

import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tarfile


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def backup(database, uploads, destination):
    database = Path(database).resolve(strict=True)
    uploads = Path(uploads).resolve(strict=True)
    destination = Path(destination).resolve()
    if not database.is_file():
        raise ValueError("database must be an existing SQLite file")
    if not uploads.is_dir():
        raise ValueError("uploads must be an existing directory")
    # Resolve symlinks first so an aliased uploads directory cannot bypass this.
    if destination == uploads or uploads in destination.parents:
        raise ValueError("backup destination must be outside the uploads directory")
    if destination.exists() and not destination.is_dir():
        raise ValueError("backup destination must be a directory")

    destination.mkdir(parents=True, exist_ok=True)
    name = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    completed = destination / name
    staging = destination / (name + ".incomplete")
    if completed.exists():
        raise FileExistsError(completed)
    staging.mkdir(exist_ok=False)

    # Closing is explicit: sqlite3's own context manager commits/rolls back but
    # does not close its connection. Close before hashing or archiving outputs.
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=30)) as source:
        with closing(sqlite3.connect(staging / "ctf_platform.db")) as target:
            source.backup(target)
            result = target.execute("PRAGMA integrity_check").fetchall()
            if result != [("ok",)]:
                raise RuntimeError("SQLite backup integrity_check failed: " + repr(result))

    with tarfile.open(staging / "uploads.tar.gz", "w:gz") as archive:
        archive.add(uploads, arcname="uploads", recursive=True)

    manifest = {name: sha256_file(staging / name) for name in ("ctf_platform.db", "uploads.tar.gz")}
    (staging / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    staging.rename(completed)
    return completed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", required=True)
    parser.add_argument("--uploads", required=True)
    parser.add_argument("--destination", required=True)
    args = parser.parse_args()
    os.umask(0o077)
    try:
        result = backup(args.database, args.uploads, args.destination)
    except (OSError, ValueError, sqlite3.Error, tarfile.TarError, RuntimeError) as exc:
        parser.exit(1, "Backup failed: " + str(exc) + "\n")
    print(result)


if __name__ == "__main__":
    main()
