"""Exercise backup.py entirely inside temporary directories; no real data is read.

Run: python3 scripts/verify_backup.py
Uses only Python's standard library and leaves no fixture databases behind.
"""

from contextlib import closing
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import threading


BACKUP_SCRIPT = Path(__file__).resolve().with_name("backup.py")
ARTIFACTS = {"ctf_platform.db", "uploads.tar.gz"}


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            value.update(block)
    return value.hexdigest()


def verify_manifest(directory):
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    check(set(manifest) == ARTIFACTS, "manifest must list exactly the database and uploads archive")
    check({path.name for path in directory.iterdir()} == ARTIFACTS | {"manifest.json"}, "unexpected or missing backup artifacts")
    for name, expected in manifest.items():
        check(isinstance(expected, str) and len(expected) == 64, "invalid SHA-256 digest")
        check(digest(directory / name) == expected, "manifest checksum mismatch: " + name)
    return manifest


def filesystem_snapshot(directory):
    files = {}
    directories = set()
    for path in directory.rglob("*"):
        name = path.relative_to(directory).as_posix()
        if path.is_dir():
            directories.add(name)
        else:
            check(path.is_file() and not path.is_symlink(), "fixture contains unexpected special file")
            files[name] = digest(path)
    return files, directories


def run_backup(database, uploads, destination, success=True):
    result = subprocess.run(
        [sys.executable, str(BACKUP_SCRIPT), "--database", str(database), "--uploads", str(uploads), "--destination", str(destination)],
        text=True, capture_output=True, timeout=45,
    )
    if not success:
        check(result.returncode != 0, "unsafe destination was accepted")
        check("outside the uploads directory" in result.stderr, "rejection did not identify the destination problem")
        return None
    check(result.returncode == 0, "backup command failed: " + result.stderr)
    output = Path(result.stdout.strip()).resolve()
    check(output.parent == destination.resolve(), "backup escaped its destination")
    check(output.is_dir() and not output.name.endswith(".incomplete"), "backup is incomplete")
    return output


def add_transaction(connection, sequence):
    connection.execute("INSERT INTO transactions(sequence, expected_parts) VALUES (?, 2)", (sequence,))
    connection.executemany(
        "INSERT INTO entries(sequence, part, payload) VALUES (?, ?, ?)",
        [(sequence, part, ("transaction-%d-part-%d" % (sequence, part)).encode()) for part in (0, 1)],
    )
    connection.execute("UPDATE snapshot SET sequence=?", (sequence,))


def inspect_database(path):
    with closing(sqlite3.connect(path)) as connection:
        check(connection.execute("PRAGMA integrity_check").fetchall() == [("ok",)], "restored integrity_check failed")
        check(connection.execute("PRAGMA foreign_key_check").fetchall() == [], "restored foreign key consistency failed")
        sequence = connection.execute("SELECT sequence FROM snapshot").fetchone()[0]
        transactions = connection.execute("SELECT sequence, expected_parts FROM transactions ORDER BY sequence").fetchall()
        entries = connection.execute("SELECT sequence, part, payload FROM entries ORDER BY sequence, part").fetchall()
        check(transactions == [(number, 2) for number in range(sequence + 1)], "backup has a partial or out-of-order transaction")
        expected = [(number, part, ("transaction-%d-part-%d" % (number, part)).encode()) for number in range(sequence + 1) for part in (0, 1)]
        check(entries == expected, "backup transaction rows do not match its snapshot marker")
        return sequence, transactions, entries


def restore_and_check(backup_dir, restore_dir, uploads, source_connection):
    verify_manifest(backup_dir)
    restore_dir.mkdir()
    shutil.copyfile(backup_dir / "ctf_platform.db", restore_dir / "ctf_platform.db")
    with tarfile.open(backup_dir / "uploads.tar.gz", "r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        check(len(names) == len(set(names)), "duplicate archive members")
        for member in members:
            resolved = (restore_dir / member.name).resolve()
            check(restore_dir.resolve() in resolved.parents, "archive member escaped restore directory")
            check(member.isfile() or member.isdir(), "unexpected link or device in fixture backup")
            check(member.name == "uploads" or member.name.startswith("uploads/"), "unexpected archive prefix")
        # All members have been checked above; the fresh target has no symlinks.
        archive.extractall(restore_dir, members=members, filter="data")
    check(filesystem_snapshot(restore_dir / "uploads") == filesystem_snapshot(uploads), "restored uploads differ from the original fixture")
    sequence, transactions, entries = inspect_database(restore_dir / "ctf_platform.db")
    expected_transactions = source_connection.execute("SELECT sequence, expected_parts FROM transactions WHERE sequence <= ? ORDER BY sequence", (sequence,)).fetchall()
    expected_entries = source_connection.execute("SELECT sequence, part, payload FROM entries WHERE sequence <= ? ORDER BY sequence, part", (sequence,)).fetchall()
    check(transactions == expected_transactions and entries == expected_entries, "restored data does not match the live database snapshot")
    return sequence


def check_tampering(backup_dir, workdir):
    for filename in ARTIFACTS:
        tampered = workdir / ("tampered-" + filename.replace(".", "-"))
        shutil.copytree(backup_dir, tampered)
        with (tampered / filename).open("ab") as stream:
            stream.write(b"tampered")
        try:
            verify_manifest(tampered)
        except AssertionError as exc:
            check("checksum mismatch" in str(exc), "tampered artifact failed for an unrelated reason")
        else:
            raise AssertionError("manifest verification accepted a corrupted " + filename)


def main():
    with tempfile.TemporaryDirectory(prefix="bjxctf-backup-verify-") as temporary:
        root = Path(temporary).resolve()
        database = root / "live.db"
        uploads = root / "uploads"
        destination = root / "backups"
        (uploads / "nested" / "empty-directory").mkdir(parents=True)
        (uploads / "挑战附件").mkdir()
        (uploads / "empty.txt").write_bytes(b"")
        (uploads / "nested" / "binary.bin").write_bytes(bytes(range(256)) * 1024)
        (uploads / "挑战附件" / "read me.txt").write_text("备份恢复验证\nCTF fixture only\n", encoding="utf-8")
        (uploads / ".hidden").write_bytes(b"hidden upload")
        initial_uploads = filesystem_snapshot(uploads)

        with closing(sqlite3.connect(database, timeout=5)) as source:
            check(source.execute("PRAGMA journal_mode=WAL").fetchone()[0] == "wal", "fixture is not in WAL mode")
            source.execute("PRAGMA wal_autocheckpoint=0")
            source.execute("PRAGMA foreign_keys=ON")
            source.executescript("""
                CREATE TABLE transactions(sequence INTEGER PRIMARY KEY, expected_parts INTEGER NOT NULL);
                CREATE TABLE entries(sequence INTEGER NOT NULL REFERENCES transactions(sequence), part INTEGER NOT NULL, payload BLOB NOT NULL, PRIMARY KEY(sequence,part));
                CREATE TABLE snapshot(sequence INTEGER NOT NULL);
                INSERT INTO snapshot VALUES(-1);
            """)
            add_transaction(source, 0)
            source.commit()
            source.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            add_transaction(source, 1)
            source.commit()
            wal = database.with_name(database.name + "-wal")
            check(wal.exists() and wal.stat().st_size > 32, "fixture has no uncheckpointed WAL data")

            # A committed WAL transaction must survive; an open, uncommitted
            # transaction on the live database must not appear in the backup.
            add_transaction(source, 2)
            first = run_backup(database, uploads, destination)
            source.rollback()
            first_sequence = restore_and_check(first, root / "restore-wal", uploads, source)
            check(first_sequence == 1, "backup omitted committed WAL data or included an uncommitted transaction")

            stopped = threading.Event()
            ready = threading.Event()
            failures = []
            def writer():
                try:
                    with closing(sqlite3.connect(database, timeout=5)) as connection:
                        connection.execute("PRAGMA wal_autocheckpoint=0")
                        sequence = 2
                        while not stopped.is_set():
                            with connection:
                                add_transaction(connection, sequence)
                            ready.set()
                            sequence += 1
                            stopped.wait(0.005)
                except BaseException as exc:
                    failures.append(exc)
                    ready.set()
            thread = threading.Thread(target=writer, name="isolated-backup-writer", daemon=True)
            thread.start()
            try:
                check(ready.wait(5), "live writer did not become ready")
                check(not failures, "live writer failed: " + repr(failures))
                second = run_backup(database, uploads, destination)
            finally:
                stopped.set()
                thread.join(timeout=10)
            check(not thread.is_alive() and not failures, "live writer did not finish cleanly: " + repr(failures))
            second_sequence = restore_and_check(second, root / "restore-live", uploads, source)
            check(second_sequence >= 2, "live backup failed to include committed writer transactions")
            check_tampering(second, root)

            for invalid in (uploads, uploads / "nested" / "recursive-backups"):
                run_backup(database, uploads, invalid, success=False)
            check(filesystem_snapshot(uploads) == initial_uploads, "unsafe destination check modified uploads")
            check(not list(destination.glob("*.incomplete")), "successful backups left incomplete directories")
            print(json.dumps({
                "result": "PASS",
                "committed_wal_included": True,
                "uncommitted_transaction_excluded": True,
                "live_snapshot_sequence": second_sequence,
                "restored_integrity_check": "ok",
                "uploads_files": len(initial_uploads[0]),
                "uploads_directories": len(initial_uploads[1]),
                "manifest_tampering_rejected": sorted(ARTIFACTS),
                "recursive_destinations_rejected": 2,
                "real_database_accessed": False,
            }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
