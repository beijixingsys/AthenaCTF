# Third-party notices

This directory preserves the notices supplied with dependencies used by the Go application
and installed production npm dependencies from both frontend lockfiles.
The Go runtime notice is included. Build-only npm tools are not redistributed here.
License metadata is copied from packages when available; the actual license text governs.
These notices do not license the AthenaCTF project itself.

Regenerate and review these notices when dependencies change.

| Component | Version | Ecosystem | Notices |
| --- | --- | --- | --- |
| github.com/dustin/go-humanize | v1.0.1 | go | [LICENSE](go-10387c8852023b63/LICENSE) |
| github.com/gabriel-vasile/mimetype | v1.4.3 | go | [LICENSE](go-466569b2bf5f8a51/LICENSE) |
| github.com/gin-contrib/sse | v0.1.0 | go | [LICENSE](go-0fcee1a6eed4087d/LICENSE) |
| github.com/gin-gonic/gin | v1.10.0 | go | [LICENSE](go-f4c5eebd2f8225ff/LICENSE) |
| github.com/go-playground/locales | v0.14.1 | go | [LICENSE](go-7230cc1c62fb00f0/LICENSE) |
| github.com/go-playground/universal-translator | v0.18.1 | go | [LICENSE](go-63debe45e5cbf399/LICENSE) |
| github.com/go-playground/validator/v10 | v10.20.0 | go | [LICENSE](go-260f161b9b5632c4/LICENSE) |
| github.com/google/uuid | v1.6.0 | go | [LICENSE](go-d0d666767bf9063c/LICENSE) |
| github.com/leodido/go-urn | v1.4.0 | go | [LICENSE](go-e6734436400ca85c/LICENSE) |
| github.com/mattn/go-isatty | v0.0.20 | go | [LICENSE](go-b24aeb3102146d70/LICENSE) |
| github.com/ncruces/go-strftime | v0.1.9 | go | [LICENSE](go-0229085b17a4f868/LICENSE) |
| github.com/pelletier/go-toml/v2 | v2.2.2 | go | [LICENSE](go-899d5ceea9bc221a/LICENSE) |
| github.com/remyoudompheng/bigfft | v0.0.0-20230129092748-24d4a6f8daec | go | [LICENSE](go-ccde9cb2b3b92254/LICENSE) |
| github.com/richardlehane/mscfb | v1.0.4 | go | [LICENSE.txt](go-6a095a8b6a154120/LICENSE.txt) |
| github.com/richardlehane/msoleps | v1.0.4 | go | [LICENSE.txt](go-77760c3042e14020/LICENSE.txt) |
| github.com/tiendc/go-deepcopy | v1.6.0 | go | [LICENSE](go-acf8b35bee476380/LICENSE) |
| github.com/ugorji/go/codec | v1.2.12 | go | [LICENSE](go-0105f6b9e6e386ec/LICENSE) |
| github.com/xuri/efp | v0.0.1 | go | [LICENSE](go-32c0cc33074d436d/LICENSE) |
| github.com/xuri/excelize/v2 | v2.9.1 | go | [LICENSE](go-7ce8e6aeba3ae824/LICENSE) |
| github.com/xuri/nfp | v0.0.1 | go | [LICENSE](go-1ca3fb94569043ab/LICENSE) |
| golang.org/x/crypto | v0.38.0 | go | [LICENSE](go-bb9661e8fa12cdee/LICENSE), [PATENTS](go-bb9661e8fa12cdee/PATENTS) |
| golang.org/x/net | v0.40.0 | go | [LICENSE](go-24e615141fb6c51c/LICENSE), [PATENTS](go-24e615141fb6c51c/PATENTS) |
| golang.org/x/sys | v0.33.0 | go | [LICENSE](go-c6107036ac87a2e5/LICENSE), [PATENTS](go-c6107036ac87a2e5/PATENTS) |
| golang.org/x/text | v0.25.0 | go | [LICENSE](go-42c7300f9a602607/LICENSE), [PATENTS](go-42c7300f9a602607/PATENTS) |
| google.golang.org/protobuf | v1.34.1 | go | [LICENSE](go-a3956126af05d26e/LICENSE), [PATENTS](go-a3956126af05d26e/PATENTS) |
| gopkg.in/yaml.v3 | v3.0.1 | go | [LICENSE](go-491112fe160db255/LICENSE), [NOTICE](go-491112fe160db255/NOTICE) |
| modernc.org/libc | v1.55.3 | go | [COPYRIGHT-MUSL](go-116191d8fec232b0/COPYRIGHT-MUSL), [LICENSE](go-116191d8fec232b0/LICENSE), [LICENSE-GO](go-116191d8fec232b0/LICENSE-GO) |
| modernc.org/mathutil | v1.6.0 | go | [LICENSE](go-626d43acd7e153c0/LICENSE) |
| modernc.org/memory | v1.8.0 | go | [LICENSE](go-ee9bc7ad495e67f6/LICENSE), [LICENSE-GO](go-ee9bc7ad495e67f6/LICENSE-GO), [LICENSE-MMAP-GO](go-ee9bc7ad495e67f6/LICENSE-MMAP-GO) |
| modernc.org/sqlite | v1.34.4 | go | [LICENSE](go-fbba94b273915223/LICENSE) |
| Go | go1.24.3 | go-runtime | [LICENSE](go-runtime-0cf428c60ae32f24/LICENSE), [PATENTS](go-runtime-0cf428c60ae32f24/PATENTS) |
| @babel/helper-string-parser | 7.27.1 | npm | [LICENSE](npm-9b2749d679938066/LICENSE) |
| @babel/helper-validator-identifier | 7.28.5 | npm | [LICENSE](npm-1ceaa61b252c46d3/LICENSE) |
| @babel/parser | 7.29.2 | npm | [LICENSE](npm-fd926779dea6cb72/LICENSE) |
| @babel/types | 7.29.0 | npm | [LICENSE](npm-57add29081c499d5/LICENSE) |
| @ctrl/tinycolor | 4.2.0 | npm | [LICENSE](npm-81aa9bac471eae0a/LICENSE) |
| @element-plus/icons-vue | 2.3.2 | npm | [LICENSE](npm-7e9e8c34ce8c7922/LICENSE) |
| @floating-ui/core | 1.7.5 | npm | [LICENSE](npm-0dc1e0a5a16c4bec/LICENSE) |
| @floating-ui/dom | 1.7.6 | npm | [LICENSE](npm-db7c3303a2cb5a80/LICENSE) |
| @floating-ui/utils | 0.2.11 | npm | [LICENSE](npm-fa536274df1352bb/LICENSE) |
| @jridgewell/sourcemap-codec | 1.5.5 | npm | [LICENSE](npm-7cc6a7e89395742a/LICENSE) |
| @sxzz/popperjs-es | 2.11.8 | npm | [LICENSE.md](npm-e2dbde47e3fff42f/LICENSE.md) |
| @types/lodash | 4.17.24 | npm | [LICENSE](npm-8ffe9cd0254c64e7/LICENSE) |
| @types/lodash-es | 4.17.12 | npm | [LICENSE](npm-0f374e7003874a91/LICENSE) |
| @types/web-bluetooth | 0.0.20 | npm | [LICENSE](npm-702da35d5c59267f/LICENSE) |
| @vue/compiler-core | 3.5.33 | npm | [LICENSE](npm-461afcf465553644/LICENSE) |
| @vue/compiler-dom | 3.5.33 | npm | [LICENSE](npm-febd5d5a02d4a916/LICENSE) |
| @vue/compiler-sfc | 3.5.33 | npm | [LICENSE](npm-151d6aae6f4db496/LICENSE) |
| @vue/compiler-ssr | 3.5.33 | npm | [LICENSE](npm-fe7af8dbbd076b1c/LICENSE) |
| @vue/devtools-api | 6.6.4 | npm |  |
| @vue/reactivity | 3.5.33 | npm | [LICENSE](npm-0ac41be09e8a3caa/LICENSE) |
| @vue/runtime-core | 3.5.33 | npm | [LICENSE](npm-4338cdba57a5fea2/LICENSE) |
| @vue/runtime-dom | 3.5.33 | npm | [LICENSE](npm-1879939a778d3d57/LICENSE) |
| @vue/server-renderer | 3.5.33 | npm | [LICENSE](npm-40fc5f2b125d9778/LICENSE) |
| @vue/shared | 3.5.33 | npm | [LICENSE](npm-b868cbd6c1b3251d/LICENSE) |
| @vueuse/core | 12.0.0 | npm | [LICENSE](npm-b14a323727257d17/LICENSE) |
| @vueuse/metadata | 12.0.0 | npm | [LICENSE](npm-381ec0d8a3f04021/LICENSE) |
| @vueuse/shared | 12.0.0 | npm | [LICENSE](npm-a225370fcb44ce2a/LICENSE) |
| agent-base | 6.0.2 | npm |  |
| async-validator | 4.2.5 | npm | [LICENSE.md](npm-dd79d1ccc82b92e8/LICENSE.md) |
| asynckit | 0.4.0 | npm | [LICENSE](npm-e54c0004f31bd078/LICENSE) |
| axios | 1.20.0 | npm | [LICENSE](npm-64964b1c4273ee54/LICENSE) |
| call-bind-apply-helpers | 1.0.2 | npm | [LICENSE](npm-4609144d3832c8d2/LICENSE) |
| combined-stream | 1.0.8 | npm | [License](npm-bdadd8ca27a3d78f/License) |
| csstype | 3.2.3 | npm | [LICENSE](npm-d75166202534f28b/LICENSE) |
| dayjs | 1.11.20 | npm | [LICENSE](npm-ab71e9759e56bc1e/LICENSE) |
| debug | 4.4.3 | npm | [LICENSE](npm-6390bf853aed627e/LICENSE) |
| delayed-stream | 1.0.0 | npm | [License](npm-cff14fcf469afa09/License) |
| dunder-proto | 1.0.1 | npm | [LICENSE](npm-390fd69f2035b583/LICENSE) |
| element-plus | 2.13.7 | npm | [LICENSE](npm-96f79c178bde605b/LICENSE) |
| entities | 7.0.1 | npm | [LICENSE](npm-550970cdda4184ad/LICENSE) |
| es-define-property | 1.0.1 | npm | [LICENSE](npm-6a37646cc624feb0/LICENSE) |
| es-errors | 1.3.0 | npm | [LICENSE](npm-645b141d3027520f/LICENSE) |
| es-object-atoms | 1.1.2 | npm | [LICENSE](npm-6c43e9e16513bd04/LICENSE) |
| es-set-tostringtag | 2.1.0 | npm | [LICENSE](npm-26f2706fefe123e5/LICENSE) |
| estree-walker | 2.0.2 | npm | [LICENSE](npm-a553e3a0980556a1/LICENSE) |
| follow-redirects | 1.16.0 | npm | [LICENSE](npm-9f96723997a6ed8e/LICENSE) |
| form-data | 4.0.6 | npm | [License](npm-f78599f94cbc9921/License) |
| function-bind | 1.1.2 | npm | [LICENSE](npm-83de3b394293d96f/LICENSE) |
| get-intrinsic | 1.3.0 | npm | [LICENSE](npm-ed58a6c65bdcf204/LICENSE) |
| get-proto | 1.0.1 | npm | [LICENSE](npm-abfbcfda1d91167a/LICENSE) |
| gopd | 1.2.0 | npm | [LICENSE](npm-f757cb02c87ace65/LICENSE) |
| has-symbols | 1.1.0 | npm | [LICENSE](npm-c0d7b7b02fe7161b/LICENSE) |
| has-tostringtag | 1.0.2 | npm | [LICENSE](npm-e39d802569f1249b/LICENSE) |
| hasown | 2.0.4 | npm | [LICENSE](npm-ba2e3a5fbd1028da/LICENSE) |
| https-proxy-agent | 5.0.1 | npm |  |
| layui | 2.13.5 | npm | [LICENSE](npm-8564892b77506faf/LICENSE) |
| lodash | 4.18.1 | npm | [LICENSE](npm-02c5607a9d3316c6/LICENSE) |
| lodash-es | 4.18.1 | npm | [LICENSE](npm-dc01c5e6fde0737b/LICENSE) |
| lodash-unified | 1.0.3 | npm |  |
| magic-string | 0.30.21 | npm | [LICENSE](npm-a2e515768834b0a4/LICENSE) |
| math-intrinsics | 1.1.0 | npm | [LICENSE](npm-f585fed67bcee1cc/LICENSE) |
| memoize-one | 6.0.0 | npm | [LICENSE](npm-92f9718d2f2cdc90/LICENSE) |
| mime-db | 1.52.0 | npm | [LICENSE](npm-7cfa78c6359b5b06/LICENSE) |
| mime-types | 2.1.35 | npm | [LICENSE](npm-a4d3481c7c7fa681/LICENSE) |
| ms | 2.1.3 | npm | [license.md](npm-2083576c5af80549/license.md) |
| nanoid | 3.3.19 | npm | [LICENSE](npm-e81b6a8c070f382c/LICENSE) |
| normalize-wheel-es | 1.2.0 | npm | [LICENSE](npm-b93738af733bec4a/LICENSE) |
| picocolors | 1.1.1 | npm | [LICENSE](npm-7c5f372425355293/LICENSE) |
| postcss | 8.5.28 | npm | [LICENSE](npm-346b76e9a17e11c7/LICENSE) |
| proxy-from-env | 2.1.0 | npm | [LICENSE](npm-892c3217563598ae/LICENSE) |
| source-map-js | 1.2.1 | npm | [LICENSE](npm-43b6dddbe93e9eda/LICENSE) |
| vue | 3.5.33 | npm | [LICENSE](npm-ac9cc7afbeccb58a/LICENSE) |
| vue-component-type-helpers | 3.2.7 | npm | [LICENSE](npm-b56b28cae19162f6/LICENSE) |
| vue-router | 4.6.4 | npm | [LICENSE](npm-dec5713789837211/LICENSE) |
