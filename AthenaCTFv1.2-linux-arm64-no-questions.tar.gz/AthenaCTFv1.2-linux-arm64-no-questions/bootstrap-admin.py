#!/usr/bin/env python3
"""Initialize the first Athena administrator using a server-generated password.
The one-time credential is displayed only on the controlling terminal, never
written to service logs or passed in command arguments. Existing accounts stay
unchanged. Requires an interactive terminal; Windows uses the same web flow.
"""
import argparse
import json
import sys
import urllib.error
import urllib.request

ADMIN_PORT_FALLBACK = "10012"


def api(base_url, path, payload=None):
    url = base_url.rstrip("/") + path
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, method="GET" if data is None else "POST")
    if data is not None:
        request.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(request, timeout=15) as response:
        body = response.read().decode("utf-8")
    parsed = json.loads(body)
    if not isinstance(parsed, dict) or "code" not in parsed:
        raise ValueError("response is not the expected API envelope")
    return parsed


def fail(message):
    print("ERROR: " + message, file=sys.stderr)
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:10010")
    parser.add_argument("--admin-url", default="", help="Administrator web UI URL for the non-TTY hint (e.g. http://127.0.0.1:10012)")
    args = parser.parse_args()
    base_url = args.base_url

    try:
        status = api(base_url, "/api/admin/bootstrap-status")
    except (urllib.error.URLError, OSError) as error:
        fail("cannot reach the local API at %s (%s). Is the platform running?" % (base_url, error))
    except ValueError as error:
        fail("unexpected bootstrap-status response from %s: %s" % (base_url, error))

    status_code = status.get("code")
    if not isinstance(status_code, int) or isinstance(status_code, bool) or status_code != 0:
        fail("bootstrap-status returned non-zero code %s; nothing was changed." % status_code)
    data_field = status.get("data")
    if not isinstance(data_field, dict) or not isinstance(data_field.get("need_bootstrap"), bool):
        fail("bootstrap-status response has a malformed need_bootstrap field (expected boolean); nothing was changed.")
    if data_field["need_bootstrap"] is not True:
        print("An administrator already exists; initialization skipped (existing accounts and data preserved).")
        return

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        # Extract the admin port from the base URL for the web-UI hint.
        admin_url = args.admin_url
        print("Non-interactive session detected.", file=sys.stderr)
        if admin_url:
            print("Options: (1) open the administrator web UI at %s and create the account there;" % admin_url, file=sys.stderr)
        else:
            print("Options: (1) open the administrator web UI (check your deployment for the admin port);", file=sys.stderr)
        print("          (2) rerun with a terminal: sudo bash deploy.sh --init-admin", file=sys.stderr)
        sys.exit(2)
    print("First administrator initialization (a random password will be generated).")
    nickname = input("Nickname [Administrator]: ").strip() or "Administrator"
    if not nickname or len(nickname) > 50:
        fail("nickname must be 1-50 characters.")
    username = input("Login username [admin]: ").strip() or "admin"
    if not username or len(username) > 50:
        fail("username must be 1-50 characters.")
    # Open the controlling terminal before creating the account, so a missing
    # terminal cannot leave a generated credential undisclosed.
    try:
        terminal = open("/dev/tty", "w", encoding="utf-8")
    except OSError:
        fail("a controlling terminal is required; use the administrator web page instead.")
    payload = {
        "admin_account_nickname": nickname,
        "admin_account_username": username,
    }
    try:
        result = api(base_url, "/api/admin/bootstrap", payload)
    except (urllib.error.URLError, OSError) as error:
        fail("bootstrap request failed (%s). The platform keeps running; rerun with a terminal." % error)
    except ValueError as error:
        fail("unexpected bootstrap response: %s" % error)
    code = result.get("code")
    if isinstance(code, int) and not isinstance(code, bool) and code == 0 and isinstance(result.get("data"), dict):
        password = result["data"].get("initial_password")
        if not isinstance(password, str) or not 32 <= len(password) <= 64:
            fail("the server did not return the generated credential; verify that frontend and backend versions match.")
        with terminal:
            terminal.write("\nAthena administrator created. Save this one-time credential:\n")
            terminal.write("Username: %s\nPassword: %s\n\n" % (username, password))
            terminal.flush()
            input("Press Enter after saving the credential: ")
        del password, result
        return
    fail("bootstrap failed: %s" % str(result.get("message", "unknown API error (code %s)" % result.get("code")))[:300])


if __name__ == "__main__":
    main()
