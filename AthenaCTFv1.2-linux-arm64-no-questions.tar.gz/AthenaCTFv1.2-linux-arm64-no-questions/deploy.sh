#!/usr/bin/env bash
# bjxctfptv2 recommended entry: install/register the platform service and
# finish first-run initialization from this terminal.
#   bash deploy.sh --check        read-only environment report
#   bash deploy.sh                interactive deploy (asks before installing
#                                 Docker; offers random-password admin bootstrap)
#   bash deploy.sh --no-docker    deploy platform-only; never installs Docker
#   bash deploy.sh --init-admin   hidden-input first-admin initialization only
#   bash deploy.sh --publish      switch an initialized install to 0.0.0.0
# Supported: Ubuntu 22.04/24.04 and Debian 12/13, amd64/arm64, systemd.
# Idempotent: existing config.env, data and accounts are preserved.
set -euo pipefail
SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
. "$(dirname -- "$SCRIPT_PATH")/platform-common.sh"
publish=0; init_admin=0; no_docker=0
case "${1:-}" in
    --check) [[ $# == 1 ]] || die 'Usage: bash deploy.sh [--check|--publish|--init-admin|--no-docker]'; check_report; exit $? ;;
    --publish) [[ $# == 1 ]] || die 'Usage: bash deploy.sh [--check|--publish|--init-admin|--no-docker]'; publish=1 ;;
    --init-admin) [[ $# == 1 ]] || die 'Usage: bash deploy.sh [--check|--publish|--init-admin|--no-docker]'; init_admin=1 ;;
    --no-docker) [[ $# == 1 ]] || die 'Usage: bash deploy.sh --no-docker'; no_docker=1 ;;
    '') [[ $# == 0 ]] || die 'Usage: bash deploy.sh [--check|--publish|--init-admin|--no-docker]'; publish=0 ;;
    *) die 'Usage: bash deploy.sh [--check|--publish|--init-admin|--no-docker]' ;;
esac
require_root "$@"
check_host
trap 'printf "Deployment failed at line %s. Fix the error and rerun; existing data is preserved.\n" "$LINENO" >&2' ERR

# Refuse to overwrite an unrelated service, even before installing dependencies.
if [[ -e "$SERVICE_FILE" ]]; then
    assert_service_matches
elif [[ "$(systemctl show "$SERVICE_NAME" -p LoadState --value)" == loaded ]]; then
    die 'An existing platform service is installed elsewhere. It will not be replaced.'
fi

if (( init_admin )); then
    assert_service_matches
    load_config
    if ! systemctl is-active --quiet "$SERVICE_NAME"; then
        /bin/bash "$PACKAGE_ROOT/start.sh"
    fi
    bootstrap_admin_via_python
    log 'Next: run "sudo bash deploy.sh --publish" when ready to serve the competition network.'
    exit 0
fi

if (( publish )); then
    assert_service_matches
    load_config
    /bin/bash "$PACKAGE_ROOT/start.sh"
    bootstrap="$(curl --noproxy '*' -fsS --max-time 10 --url "http://$HEALTH_HOST:$API_PORT/api/admin/bootstrap-status")"
    [[ "$bootstrap" =~ \"need_bootstrap\"[[:space:]]*:[[:space:]]*false ]] || die 'Create the first administrator first (web UI or: sudo bash deploy.sh --init-admin). No network binding was changed.'
    if [[ "$BIND_HOST" == 0.0.0.0 ]]; then
        log 'Already published on all IPv4 interfaces.'
        exit 0
    fi
    backup="$CONFIG_FILE.before-publish-$(date +%Y%m%d-%H%M%S)"
    cp -p -- "$CONFIG_FILE" "$backup"
    temp_config="$(mktemp "$PACKAGE_ROOT/.config.env.XXXXXX")"
    awk '
        /^[[:space:]]*CTF_BIND_HOST[[:space:]]*=/ { print "CTF_BIND_HOST=0.0.0.0"; found=1; next }
        { print }
        END { if (!found) print "CTF_BIND_HOST=0.0.0.0" }
    ' "$CONFIG_FILE" > "$temp_config"
    chown root:"$SERVICE_USER" "$temp_config"
    chmod 0640 "$temp_config"
    mv -- "$temp_config" "$CONFIG_FILE"
    log "Publishing on all IPv4 interfaces. Previous configuration: $backup"
    systemctl restart "$SERVICE_NAME"
    load_config
    wait_platform
    log "Contestant: http://<server-ip>:$USER_PORT  Administrator: http://<server-ip>:$ADMIN_PORT"
    log 'Configure the host/cloud firewall for your competition network; no firewall or SSH settings were changed.'
    exit 0
fi

log "Preparing Linux $PACKAGE_ARCH deployment in $PACKAGE_ROOT."
missing_packages=()
command -v curl >/dev/null || missing_packages+=(curl)
dpkg-query -W -f='${Status}' ca-certificates 2>/dev/null | grep -q 'install ok installed' || missing_packages+=(ca-certificates)
command -v ss >/dev/null || missing_packages+=(iproute2)
command -v pgrep >/dev/null || missing_packages+=(procps)
command -v python3 >/dev/null || missing_packages+=(python3)
if (( ${#missing_packages[@]} )); then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing_packages[@]}"
fi

# Docker is ONLY needed for container-based questions. The platform itself
# (management UI, empty-database initialization, static questions) runs
# without it. An existing installation is always kept; other runtimes are
# never uninstalled or replaced. A failed/declined Docker install continues
# the deployment platform-only with an explicit warning.
docker_installed=0
if command -v docker >/dev/null || [[ "$(systemctl show docker.service -p LoadState --value)" == loaded ]]; then
    command -v docker >/dev/null || die 'Docker service exists but its CLI is missing. Repair the existing installation; it will not be replaced.'
    log 'Keeping the existing Docker installation.'
    docker_installed=1
elif (( no_docker )); then
    log 'Skipping Docker installation (--no-docker). Container questions are unavailable; platform management and static questions work.'
else
    # Do not uninstall or replace another container runtime automatically.
    conflicts=()
    for package in docker.io docker-compose docker-compose-v2 docker-doc docker-buildx podman-docker containerd runc; do
        if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then conflicts+=("$package"); fi
    done
    if (( ${#conflicts[@]} )); then
        log "WARNING: existing container runtime packages need operator review (${conflicts[*]}). Continuing WITHOUT Docker; container questions are unavailable. Resolve and rerun to install Docker CE."
    else
        install_docker=y
        if [[ -t 0 ]]; then
            printf 'Install local Docker Engine (official signed apt repository) for container-based questions? [Y/n]: '
            IFS= read -r answer || answer=y
            case "$answer" in n|N|no|No|NO) install_docker=n ;; esac
        fi
        if [[ "$install_docker" == n ]]; then
            log 'Skipping Docker installation by request. Container questions are unavailable; rerun deploy.sh (without --no-docker) to install Docker later.'
        else
            for source_file in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
                [[ -f "$source_file" ]] || continue
                if grep -q 'download\.docker\.com' "$source_file"; then
                    [[ "$source_file" == /etc/apt/sources.list.d/bjxctf-docker.sources ]] || die "Existing Docker apt source: $source_file. Repair/reuse that source before rerunning; it will not be overwritten."
                fi
            done
            log 'Installing Docker Engine from the official signed apt repository.'
            # Source: https://docs.docker.com/engine/install/ubuntu/
            # Source: https://docs.docker.com/engine/install/debian/
            install -d -m 0755 /etc/apt/keyrings
            key_temp="$(mktemp)"
            curl --proto '=https' --tlsv1.2 -fSL --retry 3 --connect-timeout 20 --max-time 120 \
                "https://download.docker.com/linux/$DISTRO_ID/gpg" -o "$key_temp" \
                || log 'WARNING: Docker repository key download failed. Continuing WITHOUT Docker; container questions are unavailable. Fix network access and rerun deploy.sh.'
            if [[ -f "$key_temp" ]] && grep -q 'BEGIN PGP PUBLIC KEY BLOCK' "$key_temp" 2>/dev/null; then
                install -m 0644 "$key_temp" /etc/apt/keyrings/bjxctf-docker.asc
                rm -- "$key_temp"
                cat > /etc/apt/sources.list.d/bjxctf-docker.sources <<BJXCTF_DOCKER_SOURCES_EOF
Types: deb
URIs: https://download.docker.com/linux/$DISTRO_ID
Suites: $DISTRO_CODENAME
Components: stable
Architectures: $PACKAGE_ARCH
Signed-By: /etc/apt/keyrings/bjxctf-docker.asc
BJXCTF_DOCKER_SOURCES_EOF
                chmod 0644 /etc/apt/sources.list.d/bjxctf-docker.sources
                apt-get update
                if DEBIAN_FRONTEND=noninteractive apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin; then
                    docker_installed=1
                else
                    log 'WARNING: Docker CE installation failed. Continuing WITHOUT Docker; container questions are unavailable. Fix the error and rerun deploy.sh.'
                fi
            else
                rm -f -- "$key_temp"
                log 'WARNING: continuing WITHOUT Docker; container questions are unavailable. Fix network access and rerun deploy.sh.'
            fi
        fi
    fi
fi
if (( docker_installed )); then
    ensure_docker_started || true
    systemctl enable docker.service
else
    log 'Platform-only mode: Docker is not required for management, initialization or static questions.'
fi

if id "$SERVICE_USER" >/dev/null 2>&1; then
    existing_home="$(getent passwd "$SERVICE_USER" | cut -d: -f6)"
    existing_uid="$(id -u "$SERVICE_USER")"
    [[ "$existing_home" == "$PACKAGE_ROOT" && "$existing_uid" -gt 0 && "$existing_uid" -lt 1000 ]] || die 'The ctf-platform account already exists for another purpose. Use its original package or resolve the account conflict.'
else
    useradd --system --user-group --home-dir "$PACKAGE_ROOT" --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
if (( docker_installed )); then
    getent group docker >/dev/null || die 'The local Docker installation must provide the docker group.'
    usermod -aG docker "$SERVICE_USER"
fi
getent group "$SERVICE_USER" >/dev/null || die 'The platform service group is missing.'
for directory in data logs; do
    [[ ! -L "$PACKAGE_ROOT/$directory" ]] || die "$directory must be a regular directory, not a symlink."
    install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 "$PACKAGE_ROOT/$directory"
done
if [[ ! -e "$CONFIG_FILE" ]]; then
    install -o root -g "$SERVICE_USER" -m 0640 "$PACKAGE_ROOT/config.env.example" "$CONFIG_FILE"
    log 'Created config.env. This installation does not import any question bank or old database.'
else
    [[ ! -L "$CONFIG_FILE" ]] || die 'config.env must not be a symbolic link.'
    log 'Preserving existing config.env and data.'
    chown root:"$SERVICE_USER" "$CONFIG_FILE"
    chmod 0640 "$CONFIG_FILE"
fi
load_config
assert_bootstrap_bind
if [[ ! -e "$SERVICE_FILE" && "$BIND_HOST" != 127.0.0.1 ]]; then
    die 'A fresh installation must start with CTF_BIND_HOST=127.0.0.1. Initialize the administrator, then use deploy.sh --publish.'
fi
# Require a dedicated, traversable installation path, without widening parent permissions.
for readable in "$PACKAGE_ROOT/run.sh" "$PACKAGE_ROOT/web/user/index.html" "$PACKAGE_ROOT/web/admin/index.html"; do
    runuser -u "$SERVICE_USER" -- test -r "$readable" || die "The service account cannot read $readable. Place the package under /opt and allow directory traversal."
done
chmod 0755 "$PACKAGE_ROOT/bin/ctf-platform" "$PACKAGE_ROOT/run.sh" \
    "$PACKAGE_ROOT/deploy.sh" "$PACKAGE_ROOT/start.sh" "$PACKAGE_ROOT/stop.sh"
touch "$PACKAGE_ROOT/logs/platform.log"
chown "$SERVICE_USER:$SERVICE_USER" "$PACKAGE_ROOT/logs/platform.log"
chmod 0640 "$PACKAGE_ROOT/logs/platform.log"
# Existing uploads/database files may have been copied by root during a restore.
chown -hR "$SERVICE_USER:$SERVICE_USER" "$PACKAGE_ROOT/data"

# Wants=/After= (not Requires=): the platform must start even when the local
# Docker service is absent or failed - container questions degrade gracefully.
cat > "$SERVICE_FILE" <<SERVICE_UNIT_EOF
# Managed by BJXCTF clean installer
[Unit]
Description=BJXCTF Competition Platform
After=network-online.target docker.service
Wants=network-online.target docker.service

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$PACKAGE_ROOT
Environment=GIN_MODE=release
Environment=CTF_DOCKER_HOST=$DOCKER_SOCKET
ExecStart=/bin/bash $PACKAGE_ROOT/run.sh
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
KillMode=control-group
UMask=0027
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
StandardOutput=append:$PACKAGE_ROOT/logs/platform.log
StandardError=append:$PACKAGE_ROOT/logs/platform.log

[Install]
WantedBy=multi-user.target
SERVICE_UNIT_EOF
chmod 0644 "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
if (( docker_installed )); then
    ensure_docker_started || true
fi
/bin/bash "$PACKAGE_ROOT/start.sh"
log 'Deployment completed. Data and uploaded files are in data/; logs are in logs/.'
# First administrator: hidden terminal input against the LOCAL API when a
# terminal is attached; otherwise print exact next steps without waiting.
if bootstrap_admin_via_python; then
    if [[ "$BIND_HOST" == 127.0.0.1 && -t 0 ]]; then
        printf 'Publish to the competition network now (rebind 0.0.0.0)? [y/N]: '
        IFS= read -r answer || answer=n
        case "$answer" in y|Y|yes|Yes|YES) exec /bin/bash "$SCRIPT_PATH" --publish ;; esac
    fi
    if [[ "$BIND_HOST" == 127.0.0.1 ]]; then
        log 'Still bound to 127.0.0.1 for safe initialization. When ready: sudo bash deploy.sh --publish'
    fi
else
    # bootstrap failed: the platform service is running but the first
    # administrator was NOT created. Propagate the non-zero exit code.
    log 'ERROR: administrator initialization failed. The platform is running; fix the issue and rerun deploy.sh --init-admin.'
    exit 1
fi
