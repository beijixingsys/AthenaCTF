// Resolve appearance before the application stylesheet paints the first page.
;(function () {
  var preference = 'light'
  try {
    var saved = window.localStorage.getItem('ctf-user-theme')
    if (['light', 'dark', 'system'].indexOf(saved) !== -1) preference = saved
  } catch (_) { /* This page also works when browser storage is unavailable. */ }
  var dark = preference === 'dark' || (preference === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)
  var root = document.documentElement
  root.dataset.themePreference = preference
  root.dataset.theme = dark ? 'dark' : 'light'
  root.style.colorScheme = dark ? 'dark' : 'light'
  var meta = document.querySelector('meta[name="theme-color"]')
  if (meta) meta.content = dark ? '#151a23' : '#f5f7fa'
})()
