#!/usr/bin/env bash
set -euo pipefail
SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
. "$(dirname -- "$SCRIPT_PATH")/platform-common.sh"
case "${1:-}" in
    --check) [[ $# == 1 ]] || die 'Usage: bash start.sh [--check|--restart]'; check_report; exit $? ;;
    --restart) [[ $# == 1 ]] || die 'Usage: bash start.sh [--check|--restart]'; restart=1 ;;
    '') [[ $# == 0 ]] || die 'Usage: bash start.sh [--check|--restart]'; restart=0 ;;
    *) die 'Usage: bash start.sh [--check|--restart]' ;;
esac
require_root "$@"
check_host
assert_service_matches
load_config
assert_bootstrap_bind
ensure_docker_started || log 'Continuing without Docker: management, initialization and static questions work; container questions are unavailable.'
if (( restart )); then
    log 'Restarting the platform to load current configuration.'
    systemctl restart "$SERVICE_NAME"
else
    log 'Starting the platform (an active service is kept running).'
    systemctl start "$SERVICE_NAME"
fi
wait_platform
print_bootstrap_help
