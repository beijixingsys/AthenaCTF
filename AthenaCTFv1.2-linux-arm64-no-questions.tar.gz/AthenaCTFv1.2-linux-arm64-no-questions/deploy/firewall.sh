#!/usr/bin/env bash
# Run on a dedicated challenge node AFTER Docker starts. This script only
# manages CTF-owned filter chains. It does not flush Docker or host rules.
# Match CTF_CHALLENGE_CIDR to the dedicated default-address-pools in daemon.json.
set -euo pipefail
CTF_CHALLENGE_CIDR="${CTF_CHALLENGE_CIDR:-172.28.0.0/16}"
[[ "$EUID" -eq 0 ]] || { echo 'Run as root on the challenge node'; exit 1; }
for dependency in iptables iptables-restore python3 flock mktemp; do
    command -v "$dependency" >/dev/null || { echo "Missing required command: $dependency" >&2; exit 1; }
done
python3 - "$CTF_CHALLENGE_CIDR" <<'PY'
import ipaddress,sys
n=ipaddress.ip_network(sys.argv[1],strict=True)
assert n.version==4 and n.is_private and n.prefixlen>=16,'Use a dedicated private IPv4 CIDR, at most /16'
PY
# Serialize this installer, including its inspection of the existing jumps.
# iptables-restore also takes the xtables lock when testing and committing.
exec 9>/run/ctf-firewall.lock
flock -x 9
docker_user_rules=$(iptables -w 10 -S DOCKER-USER) || { echo 'Docker must use its iptables firewall backend; do not apply this script to an nftables-only backend.' >&2; exit 1; }
input_rules=$(iptables -w 10 -S INPUT)
umask 077
rules_file=$(mktemp)
trap 'rm -f -- "$rules_file"' EXIT

# With --noflush, only the declared CTF chains are replaced. Both chains and
# their jumps commit in one filter-table transaction; no live chain is emptied
# before the replacement is ready. Existing host/Docker chains are preserved.
{
    printf '%s\n' '*filter' ':CTF-EGRESS - [0:0]' ':CTF-HOST - [0:0]'
    printf '%s\n' '-A CTF-EGRESS -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN'
    printf '%s\n' "-A CTF-EGRESS -s $CTF_CHALLENGE_CIDR -j DROP" '-A CTF-EGRESS -j RETURN'
    printf '%s\n' '-A CTF-HOST -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN'
    printf '%s\n' "-A CTF-HOST -s $CTF_CHALLENGE_CIDR -j DROP" '-A CTF-HOST -j RETURN'
    # Replace only our exact jumps, removing old duplicates and restoring their
    # first position so earlier ACCEPT rules cannot bypass the CTF policy.
    while IFS= read -r rule; do
        if [[ "$rule" == '-A DOCKER-USER -j CTF-EGRESS' ]]; then
            printf '%s\n' '-D DOCKER-USER -j CTF-EGRESS'
        fi
    done <<< "$docker_user_rules"
    while IFS= read -r rule; do
        if [[ "$rule" == '-A INPUT -j CTF-HOST' ]]; then
            printf '%s\n' '-D INPUT -j CTF-HOST'
        fi
    done <<< "$input_rules"
    printf '%s\n' '-I DOCKER-USER 1 -j CTF-EGRESS' '-I INPUT 1 -j CTF-HOST' 'COMMIT'
} > "$rules_file"

if ! iptables-restore --wait 10 --noflush --test < "$rules_file"; then
    echo 'CTF policy preflight failed; existing rules were not changed.' >&2
    exit 1
fi
if ! iptables-restore --wait 10 --noflush < "$rules_file"; then
    echo 'CTF policy transaction failed; the previous rules remain in place.' >&2
    exit 1
fi
echo 'CTF outbound/host-access policy applied. Verify from a real challenge container before opening the contest.'
