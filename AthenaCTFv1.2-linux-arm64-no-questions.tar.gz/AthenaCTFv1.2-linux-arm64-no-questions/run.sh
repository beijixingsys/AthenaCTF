#!/usr/bin/env bash
set -euo pipefail
umask 077
package_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
config_path="$package_root/config.env"
# Clear inherited CTF_*/DOCKER_* variables so a parent shell's bank root,
# vault root or Docker endpoint cannot leak into this platform process.
# The explicit config.env (loaded next) always wins.
for inherited in $(compgen -e | grep -E '^(CTF_|DOCKER_)'); do
    unset "$inherited"
done
if [[ -f "$config_path" ]]; then
    while IFS= read -r config_line || [[ -n "$config_line" ]]; do
        config_line="${config_line%$'\r'}"
        config_line="${config_line#$'\xef\xbb\xbf'}"
        config_line="${config_line#"${config_line%%[![:space:]]*}"}"
        config_line="${config_line%"${config_line##*[![:space:]]}"}"
        [[ -z "$config_line" || "$config_line" == \#* ]] && continue
        if [[ ! "$config_line" =~ ^([A-Z][A-Z0-9_]*)[[:space:]]*=(.*)$ ]]; then
            printf '%s\n' 'Invalid config.env line; expected KEY=VALUE' >&2; exit 1
        fi
        config_key="${BASH_REMATCH[1]}"; config_value="${BASH_REMATCH[2]}"
        if [[ ! "$config_key" =~ ^(CTF_[A-Z0-9_]+|GIN_MODE|TZ|DOCKER_HOST|DOCKER_CONTEXT|DOCKER_CONFIG|DOCKER_TLS_VERIFY|DOCKER_CERT_PATH)$ ]]; then
            printf 'Unsupported configuration key: %s\n' "$config_key" >&2; exit 1
        fi
        config_value="${config_value#"${config_value%%[![:space:]]*}"}"
        config_value="${config_value%"${config_value##*[![:space:]]}"}"
        if [[ ${#config_value} -ge 2 && ( "$config_value" == \"*\" || "$config_value" == \'*\' ) ]]; then
            config_value="${config_value:1:${#config_value}-2}"
        fi
        export "$config_key=$config_value"
    done < "$config_path"
fi
export GIN_MODE="${GIN_MODE:-release}"
export TZ="${TZ:-Asia/Shanghai}"
export CTF_BIND_HOST="${CTF_BIND_HOST:-127.0.0.1}"
export CTF_APP_PORT="${CTF_APP_PORT:-10010}"
export CTF_USER_WEB_PORT="${CTF_USER_WEB_PORT:-10011}"
export CTF_ADMIN_WEB_PORT="${CTF_ADMIN_WEB_PORT:-10012}"
export CTF_DB_PATH="${CTF_DB_PATH:-$package_root/data/ctf_platform.db}"
export CTF_UPLOAD_ROOT="${CTF_UPLOAD_ROOT:-$package_root/data/uploads}"
binary="$package_root/bin/ctf-platform"
if [[ ! -x "$binary" ]]; then
    printf '%s\n' 'Missing executable bin/ctf-platform; extract the complete package and check permissions' >&2; exit 1
fi
cd "$package_root"
if [[ -n "${CTF_PUBLIC_BASE_URL:-}" ]]; then printf 'Public base URL: %s\n' "$CTF_PUBLIC_BASE_URL"; fi
access_host="$CTF_BIND_HOST"
if [[ "$access_host" == '0.0.0.0' || "$access_host" == '::' || "$access_host" == '[::]' ]]; then
    printf 'Contestant (local): http://127.0.0.1:%s\n' "$CTF_USER_WEB_PORT"
    access_host='<server-ip>'
elif [[ "$access_host" == *:* && "$access_host" != \[*\] ]]; then
    access_host="[$access_host]"
fi
printf 'Contestant: http://%s:%s\nAdministrator: http://%s:%s\n' "$access_host" "$CTF_USER_WEB_PORT" "$access_host" "$CTF_ADMIN_WEB_PORT"
if [[ -z "${CTF_INSTANCE_HOST:-}" || "$CTF_INSTANCE_HOST" == 'auto' ]]; then
    printf '%s\n' 'Local Docker challenge addresses follow the hostname or IP used to access the platform.'
else
    printf 'Challenge host: %s\n' "$CTF_INSTANCE_HOST"
fi
printf 'API port: %s; bind: %s\n' "$CTF_APP_PORT" "$CTF_BIND_HOST"
printf '%s\n' 'Press Ctrl+C to stop. Read docs/DEPLOYMENT_CROSS_PLATFORM.md for deployment.'
exec "$binary" -web-root "$package_root/web" -user-port "$CTF_USER_WEB_PORT" -admin-port "$CTF_ADMIN_WEB_PORT" "$@"
