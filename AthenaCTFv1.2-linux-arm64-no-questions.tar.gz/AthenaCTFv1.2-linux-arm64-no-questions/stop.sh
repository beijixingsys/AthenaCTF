#!/usr/bin/env bash
# Default stop scope: ONLY this deployment's platform service (the systemd
# unit registered by this package's deploy.sh). It never touches Docker, any
# container, or any other application: a container name prefix cannot prove
# which installation a container belongs to. For the explicit whole-engine
# maintenance shutdown use: bash stop.sh --docker
set -euo pipefail
SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
. "$(dirname -- "$SCRIPT_PATH")/platform-common.sh"
case "${1:-}" in
    --check) [[ $# == 1 ]] || die 'Usage: bash stop.sh [--check|--docker]'; check_report; exit $? ;;
    --docker) [[ $# == 1 ]] || die 'Usage: bash stop.sh [--check|--docker]'; stop_docker=1 ;;
    '') [[ $# == 0 ]] || die 'Usage: bash stop.sh [--check|--docker]' ;;
    *) die 'Usage: bash stop.sh [--check|--docker]' ;;
esac
require_root "$@"
check_host
assert_service_matches
load_config
result=0
log 'Stopping API, contestant and administrator services (this package only).'
if ! systemctl stop "$SERVICE_NAME"; then log 'ERROR: systemd could not stop the platform.'; result=1; fi
if systemctl is-active --quiet "$SERVICE_NAME" || [[ "$(systemctl show "$SERVICE_NAME" -p MainPID --value)" != 0 ]]; then
    log 'ERROR: the platform process is still active.'; result=1
fi
if command -v ss >/dev/null; then
    for port in "$API_PORT" "$USER_PORT" "$ADMIN_PORT"; do
        if [[ -n "$(ss -H -ltn "sport = :$port")" ]]; then
            log "ERROR: port $port is still listening (possibly owned by another application); no unrelated process will be killed."; result=1
        else log "Port $port is closed."; fi
    done
else log 'ERROR: ss is missing; port shutdown cannot be verified.'; result=1; fi
if [[ "${stop_docker:-0}" == 1 ]]; then
    log 'EXPLICIT whole-engine maintenance shutdown: this stops the local Docker Engine and ALL its containers, including ones from other applications.'
    if command -v docker >/dev/null && local_docker info >/dev/null 2>&1; then
        if containers="$(local_docker ps -q)"; then
            if [[ -n "$containers" ]]; then
                mapfile -t container_ids <<< "$containers"
                if ! timeout 120 docker --host "$DOCKER_SOCKET" stop --time 30 "${container_ids[@]}"; then
                    log 'ERROR: one or more containers could not be stopped.'; result=1
                fi
            fi
        else log 'ERROR: unable to list Docker containers.'; result=1; fi
    else
        log 'Docker Engine is already stopped or unreachable.'
    fi
    docker_units=()
    for unit in docker.service docker.socket; do
        if [[ "$(systemctl show "$unit" -p LoadState --value)" == loaded ]]; then docker_units+=("$unit"); fi
    done
    if (( ${#docker_units[@]} )); then
        systemctl stop "${docker_units[@]}" || { log 'ERROR: Docker systemd shutdown failed.'; result=1; }
    fi
    for unit in "${docker_units[@]}"; do
        if systemctl is-active --quiet "$unit"; then log "ERROR: $unit remains active."; result=1; fi
    done
    if command -v docker >/dev/null && timeout 5 docker --host "$DOCKER_SOCKET" info >/dev/null 2>&1; then
        log 'ERROR: Docker Engine is still reachable.'; result=1
    fi
    if (( result == 0 )); then
        log 'Whole-engine shutdown verified. Database, uploads, images and volumes are preserved.'
    fi
else
    if command -v docker >/dev/null && local_docker info >/dev/null 2>&1; then
        log 'Docker Engine and all containers were NOT touched (default stop is platform-only).'
        log 'Use "bash stop.sh --docker" only for the explicit whole-engine maintenance shutdown.'
    fi
fi
if (( result == 0 )); then
    log 'Platform stop verified; data, uploads and configuration are preserved.'
    if [[ "${stop_docker:-0}" != 1 ]]; then log 'Use sudo bash ./start.sh to restart. Boot-time startup remains enabled.'; fi
else
    log 'Shutdown is incomplete; inspect the errors above. No data, images or volumes were deleted.'
fi
exit "$result"
