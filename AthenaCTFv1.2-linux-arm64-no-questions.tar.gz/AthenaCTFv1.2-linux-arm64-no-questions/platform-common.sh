#!/usr/bin/env bash
# Shared helpers for the clean, local-Docker deployment package.
set -euo pipefail
umask 027
export LC_ALL=C
PACKAGE_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SERVICE_NAME=ctf-platform.service
SERVICE_FILE=/etc/systemd/system/ctf-platform.service
SERVICE_USER=ctf-platform
DOCKER_SOCKET=unix:///var/run/docker.sock
CONFIG_FILE="$PACKAGE_ROOT/config.env"
declare -A CONFIG=()
log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
require_root() {
    if (( EUID != 0 )); then
        command -v sudo >/dev/null || die 'Run this script as root; sudo is not installed.'
        exec sudo -- /bin/bash "$SCRIPT_PATH" "$@"
    fi
}
check_host() {
    [[ "$PACKAGE_ROOT" =~ ^/[A-Za-z0-9_./-]+$ ]] || die 'Extract to an ASCII path without spaces, e.g. /opt/bjxctf.'
    [[ "$PACKAGE_ROOT" != / ]] || die 'Extract into a dedicated directory such as /opt/bjxctf.'
    [[ "$(uname -s)" == Linux ]] || die 'This package requires Linux.'
    [[ -r /etc/os-release ]] || die 'Cannot identify Linux distribution.'
    . /etc/os-release
    case "$ID:$VERSION_ID" in ubuntu:22.04|ubuntu:24.04|debian:12|debian:13) ;; *) die "Supported: Ubuntu 22.04/24.04, Debian 12/13; detected $ID $VERSION_ID." ;; esac
    DISTRO_ID="$ID"; DISTRO_CODENAME="${UBUNTU_CODENAME:-${VERSION_CODENAME:-}}"
    [[ "$DISTRO_CODENAME" =~ ^[a-z]+$ ]] || die 'Missing or invalid distribution codename.'
    case "$(uname -m)" in x86_64) PACKAGE_ARCH=amd64; ELF_MACHINE='62 0' ;; aarch64|arm64) PACKAGE_ARCH=arm64; ELF_MACHINE='183 0' ;; *) die 'Only amd64 and arm64 hosts are supported.' ;; esac
    [[ "$(dpkg --print-architecture)" == "$PACKAGE_ARCH" ]] || die 'Kernel and Debian package architectures do not match.'
    [[ -d /run/systemd/system ]] || die 'A systemd Linux host is required; ordinary containers and WSL sessions are unsupported.'
    command -v systemctl >/dev/null || die 'systemctl is required.'
    [[ -f "$PACKAGE_ROOT/bin/ctf-platform" && ! -L "$PACKAGE_ROOT/bin/ctf-platform" ]] || die 'Missing regular file bin/ctf-platform.'
    local header machine item
    header="$(od -An -tx1 -N6 "$PACKAGE_ROOT/bin/ctf-platform" | tr -d ' \n')"
    machine="$(od -An -tu1 -j18 -N2 "$PACKAGE_ROOT/bin/ctf-platform" | xargs)"
    [[ "$header" == 7f454c460201 && "$machine" == "$ELF_MACHINE" ]] || die "Wrong executable; use the Linux $PACKAGE_ARCH package."
    for item in run.sh web/user/index.html web/admin/index.html config.env.example; do
        [[ -f "$PACKAGE_ROOT/$item" ]] || die "Incomplete package: $item is missing."
    done
}
load_config() {
    CONFIG=()
    local line key value port
    [[ -f "$CONFIG_FILE" && ! -L "$CONFIG_FILE" ]] || die 'config.env is missing or is a symlink; run deploy.sh first.'
    while IFS= read -r line || [[ -n "$line" ]]; do
        line="${line%$'\r'}"; line="${line#$'\xef\xbb\xbf'}"
        line="${line#"${line%%[![:space:]]*}"}"; line="${line%"${line##*[![:space:]]}"}"
        [[ -z "$line" || "$line" == \#* ]] && continue
        [[ "$line" =~ ^([A-Z][A-Z0-9_]*)[[:space:]]*=(.*)$ ]] || die 'Invalid config.env; expected KEY=VALUE.'
        key="${BASH_REMATCH[1]}"; value="${BASH_REMATCH[2]}"
        [[ "$key" =~ ^(CTF_[A-Z0-9_]+|GIN_MODE|TZ|DOCKER_HOST|DOCKER_CONTEXT|DOCKER_CONFIG|DOCKER_TLS_VERIFY|DOCKER_CERT_PATH)$ ]] || die "Unsupported config key: $key"
        [[ ! -v "CONFIG[$key]" ]] || die "Duplicate config key: $key"
        value="${value#"${value%%[![:space:]]*}"}"; value="${value%"${value##*[![:space:]]}"}"
        if [[ ${#value} -ge 2 && ( "$value" == \"*\" || "$value" == \'*\' ) ]]; then value="${value:1:${#value}-2}"; fi
        CONFIG["$key"]="$value"
    done < "$CONFIG_FILE"
    BIND_HOST="${CONFIG[CTF_BIND_HOST]:-127.0.0.1}"
    API_PORT="${CONFIG[CTF_APP_PORT]:-10010}"
    USER_PORT="${CONFIG[CTF_USER_WEB_PORT]:-10011}"
    ADMIN_PORT="${CONFIG[CTF_ADMIN_WEB_PORT]:-10012}"
    DB_FILE="${CONFIG[CTF_DB_PATH]:-data/ctf_platform.db}"
    [[ "$DB_FILE" == /* ]] || DB_FILE="$PACKAGE_ROOT/$DB_FILE"
    for port in "$API_PORT" "$USER_PORT" "$ADMIN_PORT"; do
        [[ "$port" =~ ^[1-9][0-9]{0,4}$ ]] && (( port >= 1024 && port <= 65535 )) || die 'The unprivileged service requires ports from 1024 to 65535; use a reverse proxy for HTTP/HTTPS ports 80/443.'
    done
    [[ "$API_PORT" != "$USER_PORT" && "$API_PORT" != "$ADMIN_PORT" && "$USER_PORT" != "$ADMIN_PORT" ]] || die 'The three ports must be different.'
    for key in CTF_DOCKER_HOST DOCKER_HOST; do
        value="${CONFIG[$key]:-}"
        [[ -z "$value" || "$value" == "$DOCKER_SOCKET" ]] || die 'These scripts manage local rootful Docker only; remote/rootless Docker needs an operator-managed deployment.'
    done
    [[ -z "${CONFIG[DOCKER_CONTEXT]:-}" ]] || die 'DOCKER_CONTEXT is unsupported by this local-Docker service.'
    [[ "${CONFIG[GIN_MODE]:-release}" == release ]] || die 'This deployment requires GIN_MODE=release.'
    [[ -n "${CONFIG[CTF_BIND_HOST]:-}" ]] || die 'Set CTF_BIND_HOST explicitly; initialize on 127.0.0.1 before publishing.'
    case "$BIND_HOST" in
        0.0.0.0|127.0.0.1) HEALTH_HOST=127.0.0.1 ;;
        ::|'[::]'|::1|'[::1]') HEALTH_HOST='[::1]' ;;
        *) HEALTH_HOST="$BIND_HOST"; if [[ "$BIND_HOST" == *:* && "$BIND_HOST" != \[*\] ]]; then HEALTH_HOST="[$BIND_HOST]"; fi ;;
    esac
}
assert_bootstrap_bind() {
    if [[ ! -s "$DB_FILE" && "$BIND_HOST" != 127.0.0.1 ]]; then
        die 'The database is missing or empty. Use CTF_BIND_HOST=127.0.0.1 for administrator initialization, then deploy.sh --publish.'
    fi
}
assert_service_matches() {
    [[ -f "$SERVICE_FILE" && ! -L "$SERVICE_FILE" ]] || die 'Platform service is not installed; run deploy.sh from this package.'
    grep -q '^# Managed by BJXCTF clean installer$' "$SERVICE_FILE" || die 'An unmanaged ctf-platform.service exists; it will not be changed.'
    local fragment working
    fragment="$(systemctl show "$SERVICE_NAME" -p FragmentPath --value)"
    working="$(systemctl show "$SERVICE_NAME" -p WorkingDirectory --value)"
    [[ "$fragment" == "$SERVICE_FILE" && "$working" == "$PACKAGE_ROOT" ]] || die "ctf-platform.service belongs to a different package ($working). Use that package's scripts."
}
local_docker() { timeout 30 docker --host "$DOCKER_SOCKET" "$@"; }
# Tolerant readiness: container questions need Docker, but the platform
# itself (management, empty-database initialization, static questions) does
# not. Returns 1 instead of dying when the engine is missing or not ready so
# the deployment can continue platform-only with a clear warning.
ensure_docker_started() {
    if ! command -v docker >/dev/null; then
        log 'WARNING: Docker CLI is missing. Container questions are unavailable; platform management and static questions work. Run deploy.sh again to install Docker.'
        return 1
    fi
    if [[ "$(systemctl show docker.service -p LoadState --value)" != loaded ]]; then
        log 'WARNING: rootful docker.service is missing (Docker Desktop, snap and rootless Docker are unsupported here). Container questions are unavailable; the platform works without it.'
        return 1
    fi
    log 'Starting local Docker Engine.'
    systemctl start docker.service || { log 'WARNING: docker.service failed to start; container questions are unavailable. Inspect journalctl -u docker.service.'; return 1; }
    local attempt
    for attempt in {1..30}; do
        if timeout 3 docker --host "$DOCKER_SOCKET" info >/dev/null 2>&1; then
            [[ "$(local_docker info --format '{{.OSType}}')" == linux ]] || { log 'WARNING: the local Docker daemon is not Linux containers; container questions are unavailable.'; return 1; }
            return 0
        fi
        sleep 2
    done
    log 'WARNING: Docker did not become ready; container questions are unavailable. Inspect journalctl -u docker.service, then run start.sh.'
    return 1
}

wait_platform() {
    local attempt main_pid binary_path
    log 'Waiting for API, contestant and administrator endpoints.'
    for attempt in {1..30}; do
        main_pid="$(systemctl show "$SERVICE_NAME" -p MainPID --value)"
        binary_path="$(readlink -f "/proc/$main_pid/exe" 2>/dev/null || true)"
        if [[ "$main_pid" =~ ^[1-9][0-9]*$ && "$binary_path" == "$PACKAGE_ROOT/bin/ctf-platform" ]] &&
            systemctl is-active --quiet "$SERVICE_NAME" &&
            curl --noproxy '*' -fsS --max-time 2 --url "http://$HEALTH_HOST:$API_PORT/api/health" >/dev/null 2>&1 &&
            curl --noproxy '*' -fsS --max-time 2 --url "http://$HEALTH_HOST:$USER_PORT/" >/dev/null 2>&1 &&
            curl --noproxy '*' -fsS --max-time 2 --url "http://$HEALTH_HOST:$ADMIN_PORT/" >/dev/null 2>&1; then
            log "Platform is ready. API=$API_PORT contestant=$USER_PORT administrator=$ADMIN_PORT bind=$BIND_HOST"
            return
        fi
        sleep 2
    done
    die "Platform did not become ready. Read $PACKAGE_ROOT/logs/platform.log and journalctl -u $SERVICE_NAME."
}
print_bootstrap_help() {
    log "Administrator web UI: http://$HEALTH_HOST:$ADMIN_PORT"
    log 'Recommended: run "sudo bash deploy.sh --init-admin" to create the first administrator from this terminal (hidden password input).'
    log 'Alternative: open the administrator web page in a browser (SSH tunnel if remote); initialization generates a random password to save once.'
    if [[ "$BIND_HOST" == 127.0.0.1 || "$BIND_HOST" == ::1 ]]; then
        log 'After initialization: sudo bash ./deploy.sh --publish'
    fi
    log 'Challenge starts stay blocked until host network isolation is installed and verified, then CTF_NETWORK_POLICY_READY is explicitly set to 1.'
}
check_report() {
    check_host
    log "Supported host: $DISTRO_ID $VERSION_ID / $PACKAGE_ARCH; matching ELF binary."
    local missing=0
    command -v curl >/dev/null && log 'curl is installed.' || { log 'MISSING: curl (deploy.sh will install it).'; missing=1; }
    dpkg-query -W -f='${Status}' ca-certificates 2>/dev/null | grep -q 'install ok installed' && log 'CA certificates are installed.' || { log 'MISSING: ca-certificates.'; missing=1; }
    command -v ss >/dev/null || { log 'MISSING: iproute2 (port shutdown checks).'; missing=1; }
    command -v pgrep >/dev/null || { log 'MISSING: procps (Docker shutdown checks).'; missing=1; }
    if command -v docker >/dev/null; then
        log 'Docker CLI is installed; an existing installation will be preserved (container questions only).'
        if timeout 5 docker --host "$DOCKER_SOCKET" info >/dev/null 2>&1; then log 'Local Docker is reachable.'; else log 'Docker is stopped or the current user lacks socket access (container questions unavailable; platform still works).'; fi
    else log 'Docker not installed: container questions unavailable; platform management and static questions work. deploy.sh can install it.'; fi
    if [[ -f "$CONFIG_FILE" ]]; then load_config; log "Existing config.env will be preserved; bind=$BIND_HOST ports=$API_PORT/$USER_PORT/$ADMIN_PORT."; else log 'A local-only config.env and empty database will be created.'; fi
    if [[ -e "$SERVICE_FILE" ]]; then
        assert_service_matches
        log "Installed service belongs to this package; state=$(systemctl is-active "$SERVICE_NAME" || true)."
    else log 'Platform systemd service is not installed.'; fi
    log 'Check completed; no packages, files, services, or firewall rules were changed.'
    return "$missing"
}

#!/usr/bin/env bash

# Administrator API base URL follows the configured bind address (same
# mapping as the health check): 0.0.0.0 means local access during setup.
admin_base_url() {
    printf 'http://%s:%s' "$HEALTH_HOST" "$API_PORT"
}

# First-administrator initialization: delegate to bootstrap-admin.py
# (python3 stdlib json/urllib/getpass only). Credentials are read with getpass
# (hidden, never echoed), serialized with json, sent to the LOCAL API over
# HTTP via urllib - never in argv, process listings or logs. Strict handling:
# unreachable API, malformed status and API errors all exit non-zero with a
# clear message; an already-initialized platform is reported and skipped.
bootstrap_admin_via_python() {
    local base="http://$HEALTH_HOST:$API_PORT"
    if ! command -v python3 >/dev/null; then
        log 'ERROR: python3 is required for the terminal administrator initialization but is not installed.'
        log "Alternative: open http://$HEALTH_HOST:$ADMIN_PORT/ in a browser and create the first administrator there."
        return 2
    fi
    python3 "$PACKAGE_ROOT/bootstrap-admin.py" --base-url "$base" --admin-url "http://$HEALTH_HOST:$ADMIN_PORT" || return $?
}
